from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from backend.database import engine, get_db
from backend.models import PowerManagementEvent
from backend.optimization.power_schemas import PowerEvaluateRequest, PowerEvaluateResponse
from backend.optimization.power_service import power_service
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

def get_db_optional():
    if engine is not None:
        try:
            db = next(get_db())
            yield db
        except Exception:
            yield None
        finally:
            if 'db' in locals() and db is not None:
                db.close()
    else:
        yield None

@router.get("/status")
def get_power_status(db: Session = Depends(get_db_optional)):
    return {
        "service": "AI-Based Server Power Management",
        "status": "operational",
        "decision_engine": "rule-based deterministic (extensible to ML)",
        "database_available": (db is not None),
        "cloudsim_power_model": "UNAVAILABLE"
    }

@router.post("/evaluate", response_model=PowerEvaluateResponse)
def evaluate_power(request: PowerEvaluateRequest, db: Session = Depends(get_db_optional)):
    try:
        response = power_service.evaluate(request)
    except Exception as e:
        logger.error(f"Power evaluation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
        
    db_persisted = False
    
    if request.persist_decision and db is not None:
        try:
            for s in response.server_states:
                # We only log events if we decided on an action that changes state or is notable
                if s.recommended_action != "KEEP_ACTIVE":
                    record = PowerManagementEvent(
                        server_id=str(s.server_id),
                        cpu_utilization=s.cpu_utilization,
                        memory_utilization=s.ram_utilization,
                        power_consumption=s.power_consumption_w,
                        action=f"{s.recommended_action} - {s.action_status} - {s.reason}"[:100],  # Storing reason/status in action if it fits, or just action
                        estimated_power_saving=s.energy_savings_kwh
                    )
                    db.add(record)
            
            # Note: There might be zero events to log if all are KEEP_ACTIVE
            db.commit()
            db_persisted = True
        except Exception as e:
            db.rollback()
            logger.error(f"Failed to persist power management event to DB: {e}")
                
    response.database_persisted = db_persisted
    return response
