import numpy as np
from typing import List
import logging
from backend.optimization.failure_schemas import FailureAnalyzeRequest, FailureAnalyzeResponse
from backend.optimization.migration_service import migration_service
from backend.optimization.schemas import MigrationEvaluateRequest

logger = logging.getLogger(__name__)

class FailureService:
    def analyze(self, request: FailureAnalyzeRequest) -> FailureAnalyzeResponse:
        anomaly_indicators = []
        detected_reasons = []
        risk_score = 0.0
        
        # 1. Temporal Analysis & Anomaly Detection
        if not request.telemetry:
            return FailureAnalyzeResponse(
                server_id=request.server_id,
                analysis_window_size=0,
                metrics_analyzed=["cpu_utilization", "ram_utilization"],
                anomaly_indicators=[],
                risk_score=0.0,
                risk_level="UNKNOWN",
                detected_reasons=["Insufficient temporal history for analysis."],
                recommended_action="MONITOR",
                self_healing_status="NO_ACTION",
                message="Missing telemetry.",
                database_persisted=False
            )
            
        n_obs = len(request.telemetry)
        cpu_history = [obs.cpu_utilization for obs in request.telemetry]
        ram_history = [obs.ram_utilization for obs in request.telemetry]
        
        if n_obs > 3:
            cpu_mean = float(np.mean(cpu_history[:-1]))
            cpu_std = float(np.std(cpu_history[:-1]))
            ram_mean = float(np.mean(ram_history[:-1]))
            ram_std = float(np.std(ram_history[:-1]))
            
            latest_cpu = cpu_history[-1]
            latest_ram = ram_history[-1]
            
            # Z-score based anomaly detection (statistical, non-ML)
            if cpu_std > 0:
                cpu_z = (latest_cpu - cpu_mean) / cpu_std
                if cpu_z > 3.0 and latest_cpu > 70.0:
                    anomaly_indicators.append("rapid CPU increase")
                    detected_reasons.append(f"Abnormal CPU deviation (Z-score: {cpu_z:.2f})")
                    risk_score += 0.4
                    
            if ram_std > 0:
                ram_z = (latest_ram - ram_mean) / ram_std
                if ram_z > 3.0 and latest_ram > 70.0:
                    anomaly_indicators.append("abnormal memory deviation")
                    detected_reasons.append(f"Abnormal RAM deviation (Z-score: {ram_z:.2f})")
                    risk_score += 0.3
                    
        # Sustained high utilization check (last 3 observations)
        if n_obs >= 3:
            recent_cpu = cpu_history[-3:]
            recent_ram = ram_history[-3:]
            
            if all(c > 85.0 for c in recent_cpu):
                anomaly_indicators.append("sustained high CPU")
                detected_reasons.append("Sustained high CPU utilization > 85%")
                risk_score += 0.5
                
            if all(r > 85.0 for r in recent_ram):
                anomaly_indicators.append("sustained high memory")
                detected_reasons.append("Sustained high RAM utilization > 85%")
                risk_score += 0.4

        # Cap risk score
        risk_score = min(1.0, risk_score)
        
        # Map to levels
        if risk_score <= 0.30:
            risk_level = "LOW"
        elif risk_score <= 0.60:
            risk_level = "MEDIUM"
        elif risk_score <= 0.80:
            risk_level = "HIGH"
        else:
            risk_level = "CRITICAL"
            
        # 2. Self-Healing Policy (Trigger migration if HIGH/CRITICAL)
        recommended_action = "MONITOR"
        self_healing_status = "NO_ACTION"
        migrations = []
        
        if risk_level in ["HIGH", "CRITICAL"]:
            recommended_action = "MIGRATION_RECOMMENDED"
            if not request.hosts or not request.vms:
                self_healing_status = "RECOVERY_BLOCKED"
                detected_reasons.append("Migration blocked: missing hosts/VMs context.")
            else:
                host_vms = [v for v in request.vms if v.host_id == request.server_id]
                if not host_vms:
                    self_healing_status = "RECOVERY_BLOCKED"
                    detected_reasons.append("Migration blocked: no active workloads to migrate.")
                else:
                    temp_hosts = {h.id: {'cpu': h.cpu_capacity - (h.cpu_capacity * h.cpu_utilization / 100.0),
                                         'ram': h.ram_capacity - (h.ram_capacity * h.ram_utilization / 100.0),
                                         'util': h.cpu_utilization} for h in request.hosts}
                    
                    evacuation_feasible = True
                    candidate_migrations = []
                    
                    from backend.optimization.schemas import MigrationCandidate
                    for vm in host_vms:
                        best_dest = None
                        best_util = -1
                        for other_host in request.hosts:
                            if other_host.id == request.server_id:
                                continue
                            
                            available_cpu = temp_hosts[other_host.id]['cpu']
                            available_ram = temp_hosts[other_host.id]['ram']
                            
                            if available_cpu >= vm.cpu_required and available_ram >= vm.ram_required:
                                if best_dest is None or temp_hosts[other_host.id]['util'] > best_util:
                                    best_dest = other_host
                                    best_util = temp_hosts[other_host.id]['util']
                        
                        if best_dest:
                            temp_hosts[best_dest.id]['cpu'] -= vm.cpu_required
                            temp_hosts[best_dest.id]['ram'] -= vm.ram_required
                            temp_hosts[best_dest.id]['util'] += (vm.cpu_required / best_dest.cpu_capacity * 100)
                            
                            candidate_migrations.append(MigrationCandidate(
                                vm_id=vm.id,
                                source_host_id=request.server_id,
                                dest_host_id=best_dest.id,
                                reason="Self-healing evacuation due to high failure risk",
                                status="EVALUATED"
                            ))
                        else:
                            evacuation_feasible = False
                            break
                            
                    if evacuation_feasible and candidate_migrations:
                        from backend.simulation.cloudsim_service import cloudsim_service
                        from backend.simulation.schemas import SimulationRequest, CloudSimHost, CloudSimVM, MigrationRequest
                        
                        cloudsim_hosts = [CloudSimHost(id=h.id, pes=1, mips=h.cpu_capacity, ram=int(h.ram_capacity), bw=10000, storage=100000) for h in request.hosts]
                        cloudsim_vms = [CloudSimVM(id=v.id, host_id=v.host_id, pes=1, mips=v.cpu_required, ram=int(v.ram_required), bw=1000, size=1000) for v in request.vms]
                        
                        sim_request = SimulationRequest(
                            workflow_id=0,
                            hosts=cloudsim_hosts,
                            vms=cloudsim_vms,
                            cloudlets=[],
                            migrations=[MigrationRequest(vm_id=m.vm_id, target_host_id=m.dest_host_id) for m in candidate_migrations],
                            persist_run=False
                        )
                        
                        try:
                            sim_response = cloudsim_service.run_simulation(sim_request)
                            success_migrations = []
                            if sim_response.migrations:
                                for sim_m in sim_response.migrations:
                                    target_candidate = next((m for m in candidate_migrations if m.vm_id == sim_m.vm_id), None)
                                    if target_candidate:
                                        target_candidate.status = "SUCCESS" if sim_m.success else "FAILED"
                                        success_migrations.append(target_candidate)
                            
                            migrations = success_migrations
                            if migrations and all(m.status == "SUCCESS" for m in migrations):
                                self_healing_status = "MIGRATION_EXECUTED"
                                recommended_action = "MIGRATION_EXECUTED"
                            else:
                                self_healing_status = "RECOVERY_BLOCKED"
                                detected_reasons.append("Migration simulation failed or rejected by CloudSim.")
                        except Exception as e:
                            logger.error(f"Self-healing simulation failed: {e}")
                            self_healing_status = "RECOVERY_BLOCKED"
                            detected_reasons.append(f"Simulation error: {e}")
                            
                    else:
                        self_healing_status = "RECOVERY_BLOCKED"
                        detected_reasons.append("Migration blocked: insufficient destination capacity for evacuation.")

        if not detected_reasons and risk_level == "LOW":
            detected_reasons.append("Normal behavior observed.")
            
        return FailureAnalyzeResponse(
            server_id=request.server_id,
            analysis_window_size=n_obs,
            metrics_analyzed=["cpu_utilization", "ram_utilization"],
            anomaly_indicators=anomaly_indicators,
            risk_score=risk_score,
            risk_level=risk_level,
            detected_reasons=detected_reasons,
            recommended_action=recommended_action,
            self_healing_status=self_healing_status,
            migrations=migrations,
            message="Failure risk and anomaly detection completed successfully using statistical indicators.",
            database_persisted=False
        )

failure_service = FailureService()
