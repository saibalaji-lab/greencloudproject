from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from backend.database import engine, get_db
from backend.models import FailurePrediction
from backend.optimization.failure_schemas import FailureAnalyzeRequest, FailureAnalyzeResponse
from backend.optimization.failure_service import failure_service
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

def get_db_optional():
    if engine is not None:
        try:
            db = next(get_db())
            yield db
        except Exception:
            yield None
        finally:
            if 'db' in locals() and db is not None:
                db.close()
    else:
        yield None

@router.get("/status")
def get_failure_status(db: Session = Depends(get_db_optional)):
    return {
        "service": "Failure Risk & Anomaly Detection",
        "status": "operational",
        "methodology": "Statistical Anomaly/Risk Detection (Not a validated ML probability)",
        "database_available": (db is not None)
    }

@router.post("/analyze", response_model=FailureAnalyzeResponse)
def analyze_failure_risk(request: FailureAnalyzeRequest, db: Session = Depends(get_db_optional)):
    try:
        response = failure_service.analyze(request)
    except Exception as e:
        logger.error(f"Failure analysis failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
        
    db_persisted = False
    
    if request.persist_decision and db is not None:
        try:
            reasons_str = "; ".join(response.detected_reasons)
            record = FailurePrediction(
                server_id=str(response.server_id),
                failure_probability=response.risk_score, 
                anomaly_score=response.risk_score,
                failure_reason=reasons_str[:500],
                recommended_action=response.recommended_action,
                status=response.self_healing_status
            )
            db.add(record)
            db.commit()
            db_persisted = True
        except Exception as e:
            db.rollback()
            logger.error(f"Failed to persist failure prediction to DB: {e}")
                
    response.database_persisted = db_persisted
    return response
