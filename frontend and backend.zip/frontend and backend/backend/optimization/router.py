from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from backend.database import engine, get_db
from backend.models import VMMigration
from backend.optimization.schemas import MigrationEvaluateRequest, MigrationEvaluateResponse
from backend.optimization.migration_service import migration_service
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

def get_db_optional():
    if engine is not None:
        try:
            db = next(get_db())
            yield db
        except Exception:
            yield None
        finally:
            if 'db' in locals() and db is not None:
                db.close()
    else:
        yield None

@router.get("/status")
def get_migration_status(db: Session = Depends(get_db_optional)):
    return {
        "service": "Migration & Consolidation",
        "status": "operational",
        "database_available": (db is not None)
    }

@router.post("/evaluate", response_model=MigrationEvaluateResponse)
def evaluate_migration(request: MigrationEvaluateRequest, db: Session = Depends(get_db_optional)):
    try:
        response = migration_service.evaluate(request)
    except Exception as e:
        logger.error(f"Migration evaluation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
        
    db_persisted = False
    
    if request.persist_decision and db is not None:
        try:
            for m in response.selected_migrations:
                sim_run_id = request.simulation_run_id if request.simulation_run_id else None
                record = VMMigration(
                    simulation_run_id=sim_run_id,
                    vm_id=str(m.vm_id),
                    source_server_id=str(m.source_host_id),
                    destination_server_id=str(m.dest_host_id),
                    reason=m.reason,
                    status=m.status,
                    started_at=datetime.utcnow(),
                    completed_at=datetime.utcnow() if m.status in ["SUCCESS", "FAILED"] else None
                )
                db.add(record)
            
            if response.selected_migrations:
                db.commit()
                db_persisted = True
        except Exception as e:
            db.rollback()
            logger.error(f"Failed to persist migration decision to DB: {e}")
                
    response.database_persisted = db_persisted
    return response
