from pydantic import BaseModel, Field
from typing import List, Optional
from backend.optimization.schemas import HostState, VMState, MigrationCandidate

class TelemetryObservation(BaseModel):
    timestamp: str
    cpu_utilization: float
    ram_utilization: float

class FailureAnalyzeRequest(BaseModel):
    simulation_run_id: Optional[int] = None
    server_id: int
    telemetry: List[TelemetryObservation] = Field(..., description="Chronological history of resource observations")
    hosts: List[HostState] = []
    vms: List[VMState] = []
    persist_decision: bool = False

class FailureAnalyzeResponse(BaseModel):
    server_id: int
    source: str = "Telemetry"
    analysis_window_size: int
    metrics_analyzed: List[str]
    anomaly_indicators: List[str]
    risk_score: float
    risk_level: str
    detected_reasons: List[str]
    recommended_action: str
    self_healing_status: str
    migrations: List[MigrationCandidate] = []
    message: str
    database_persisted: bool
