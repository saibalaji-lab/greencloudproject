from typing import Dict, Any, List
from backend.optimization.schemas import MigrationEvaluateRequest, MigrationEvaluateResponse, MigrationCandidate, HostAfterState
from backend.simulation.cloudsim_service import cloudsim_service
from backend.simulation.schemas import SimulationRequest, CloudSimHost, CloudSimVM, CloudSimCloudlet, MigrationRequest
import logging

logger = logging.getLogger(__name__)

class MigrationService:
    def evaluate(self, request: MigrationEvaluateRequest) -> MigrationEvaluateResponse:
        overloaded_hosts = []
        candidate_vms = []
        destination_candidates = {}
        
        # 1. Detect overloaded hosts
        for host in request.hosts:
            if host.cpu_utilization > request.cpu_threshold or host.ram_utilization > request.ram_threshold:
                overloaded_hosts.append(host.id)
                
        # 2. Identify candidate VMs on overloaded hosts
        # Simple heuristic: pick the largest VM on the overloaded host
        for host_id in overloaded_hosts:
            host_vms = [vm for vm in request.vms if vm.host_id == host_id]
            if host_vms:
                # Pick the VM with highest CPU required
                largest_vm = max(host_vms, key=lambda v: v.cpu_required)
                candidate_vms.append(largest_vm.id)
                
        # 3. Find feasible destination candidates
        selected_migrations = []
        for vm_id in candidate_vms:
            vm = next(v for v in request.vms if v.id == vm_id)
            feasible_hosts = []
            
            for host in request.hosts:
                if host.id == vm.host_id:
                    continue
                
                # Check available capacity
                available_cpu = host.cpu_capacity - (host.cpu_capacity * (host.cpu_utilization / 100.0))
                available_ram = host.ram_capacity - (host.ram_capacity * (host.ram_utilization / 100.0))
                
                if available_cpu >= vm.cpu_required and available_ram >= vm.ram_required:
                    feasible_hosts.append(host)
                    
            destination_candidates[vm_id] = [h.id for h in feasible_hosts]
            
            # Select best destination (least utilized)
            if feasible_hosts:
                # Rank by lowest CPU utilization
                best_dest = min(feasible_hosts, key=lambda h: h.cpu_utilization)
                selected_migrations.append(MigrationCandidate(
                    vm_id=vm_id,
                    source_host_id=vm.host_id,
                    dest_host_id=best_dest.id,
                    reason="Resource consolidation" if not request.carbon_aware else "Carbon-aware migration",
                    status="EVALUATED"
                ))

        if not selected_migrations:
            return MigrationEvaluateResponse(
                overloaded_hosts=overloaded_hosts,
                candidate_vms=candidate_vms,
                destination_candidates=destination_candidates,
                selected_migrations=[],
                before_state={},
                after_state={},
                message="No feasible migrations found.",
                database_persisted=False
            )
            
        # 4. We will execute the migration plan via CloudSim Plus
        # Map our schema to SimulationRequest
        cloudsim_hosts = [CloudSimHost(id=h.id, pes=1, mips=h.cpu_capacity, ram=int(h.ram_capacity), bw=10000, storage=100000) for h in request.hosts]
        cloudsim_vms = [CloudSimVM(id=v.id, host_id=v.host_id, pes=1, mips=v.cpu_required, ram=int(v.ram_required), bw=1000, size=1000) for v in request.vms]
        
        sim_request = SimulationRequest(
            workflow_id=0,
            hosts=cloudsim_hosts,
            vms=cloudsim_vms,
            cloudlets=[], # No workload, just evaluating placement and migration
            migrations=[MigrationRequest(vm_id=m.vm_id, target_host_id=m.dest_host_id) for m in selected_migrations],
            persist_run=False
        )
        
        try:
            sim_response = cloudsim_service.run_simulation(sim_request)
            
            # Update selected migrations based on simulation success
            success_migrations = []
            if sim_response.migrations:
                for sim_m in sim_response.migrations:
                    target_candidate = next((m for m in selected_migrations if m.vm_id == sim_m.vm_id), None)
                    if target_candidate:
                        target_candidate.status = "SUCCESS" if sim_m.success else "FAILED"
                        success_migrations.append(target_candidate)
        except Exception as e:
            logger.error(f"Migration simulation failed: {e}")
            for m in selected_migrations:
                m.status = "SIMULATION_FAILED"
            success_migrations = selected_migrations

        # Calculate before and after state (simple projection)
        before_state = {}
        after_state = {}
        for h in request.hosts:
            before_state[h.id] = HostAfterState(cpu_utilization=h.cpu_utilization, ram_utilization=h.ram_utilization)
            after_state[h.id] = HostAfterState(cpu_utilization=h.cpu_utilization, ram_utilization=h.ram_utilization)
            
        for m in success_migrations:
            if m.status == "SUCCESS":
                vm = next(v for v in request.vms if v.id == m.vm_id)
                src = next(h for h in request.hosts if h.id == m.source_host_id)
                dest = next(h for h in request.hosts if h.id == m.dest_host_id)
                
                after_state[src.id].cpu_utilization = max(0, after_state[src.id].cpu_utilization - (vm.cpu_required / src.cpu_capacity * 100))
                after_state[src.id].ram_utilization = max(0, after_state[src.id].ram_utilization - (vm.ram_required / src.ram_capacity * 100))
                
                after_state[dest.id].cpu_utilization = min(100, after_state[dest.id].cpu_utilization + (vm.cpu_required / dest.cpu_capacity * 100))
                after_state[dest.id].ram_utilization = min(100, after_state[dest.id].ram_utilization + (vm.ram_required / dest.ram_capacity * 100))
                
        return MigrationEvaluateResponse(
            overloaded_hosts=overloaded_hosts,
            candidate_vms=candidate_vms,
            destination_candidates=destination_candidates,
            selected_migrations=success_migrations,
            before_state=before_state,
            after_state=after_state,
            message="Migration evaluation complete.",
            database_persisted=False
        )

migration_service = MigrationService()
