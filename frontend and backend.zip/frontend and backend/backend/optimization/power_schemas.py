from pydantic import BaseModel, Field
from typing import List, Optional
from backend.optimization.schemas import HostState, VMState, MigrationCandidate

class PowerEvaluateRequest(BaseModel):
    simulation_run_id: Optional[int] = None
    idle_threshold: float = Field(5.0, description="CPU threshold below which a server is IDLE")
    underutilized_threshold: float = Field(20.0, description="CPU threshold below which a server is UNDERUTILIZED")
    carbon_aware: bool = False
    hosts: List[HostState]
    vms: List[VMState]
    persist_decision: bool = False

class ServerPowerState(BaseModel):
    server_id: int
    state: str  
    cpu_utilization: float
    ram_utilization: float
    active_vms_count: int
    recommended_action: str  
    migration_required: bool
    migrations: List[MigrationCandidate] = []
    action_status: str  
    power_consumption_w: Optional[float] = None
    energy_savings_kwh: Optional[float] = None
    reason: str

class PowerEvaluateResponse(BaseModel):
    server_states: List[ServerPowerState]
    message: str
    database_persisted: bool
