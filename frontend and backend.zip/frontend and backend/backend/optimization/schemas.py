from pydantic import BaseModel, Field
from typing import List, Optional, Dict

class HostState(BaseModel):
    id: int
    cpu_capacity: float
    cpu_utilization: float
    ram_capacity: float
    ram_utilization: float

class VMState(BaseModel):
    id: int
    host_id: int
    cpu_required: float
    ram_required: float

class MigrationEvaluateRequest(BaseModel):
    simulation_run_id: Optional[int] = None
    cpu_threshold: float = Field(80.0, description="Threshold percentage for overload detection")
    ram_threshold: float = Field(80.0, description="Threshold percentage for overload detection")
    carbon_aware: bool = False
    hosts: List[HostState]
    vms: List[VMState]
    persist_decision: bool = False

class MigrationCandidate(BaseModel):
    vm_id: int
    source_host_id: int
    dest_host_id: int
    reason: str
    status: str
    
class HostAfterState(BaseModel):
    cpu_utilization: float
    ram_utilization: float

class MigrationEvaluateResponse(BaseModel):
    overloaded_hosts: List[int]
    candidate_vms: List[int]
    destination_candidates: Dict[int, List[int]]
    selected_migrations: List[MigrationCandidate]
    before_state: Dict[int, HostAfterState]
    after_state: Dict[int, HostAfterState]
    message: str
    database_persisted: bool
