from typing import List, Dict
import logging
from backend.optimization.power_schemas import PowerEvaluateRequest, PowerEvaluateResponse, ServerPowerState
from backend.optimization.schemas import MigrationCandidate

logger = logging.getLogger(__name__)

class PowerService:
    def evaluate(self, request: PowerEvaluateRequest) -> PowerEvaluateResponse:
        server_states = []
        
        for host in request.hosts:
            host_vms = [v for v in request.vms if v.host_id == host.id]
            active_vms_count = len(host_vms)
            
            state = "ACTIVE"
            recommended_action = "KEEP_ACTIVE"
            migration_required = False
            migrations = []
            action_status = "EVALUATED"
            reason = "Server utilization is normal or high."
            
            if host.cpu_utilization <= request.idle_threshold:
                if active_vms_count == 0:
                    state = "IDLE"
                    recommended_action = "SLEEP"
                    reason = "Server is idle with no active VMs."
                    action_status = "SIMULATION_SUPPORT_UNAVAILABLE" 
                else:
                    state = "UNDERUTILIZED"
                    recommended_action = "CONSOLIDATE_AND_SLEEP"
                    migration_required = True
                    reason = "Server is almost idle but has active VMs. Consolidation recommended."
            elif host.cpu_utilization <= request.underutilized_threshold:
                state = "UNDERUTILIZED"
                recommended_action = "DVFS"
                reason = "Server is underutilized. DVFS recommended to lower frequency."
                action_status = "SIMULATION_SUPPORT_UNAVAILABLE" 
                
            if migration_required:
                evacuation_feasible = True
                host_migrations = []
                
                temp_hosts = {h.id: {'cpu': h.cpu_capacity - (h.cpu_capacity * h.cpu_utilization / 100.0),
                                     'ram': h.ram_capacity - (h.ram_capacity * h.ram_utilization / 100.0),
                                     'util': h.cpu_utilization} for h in request.hosts}
                
                for vm in host_vms:
                    best_dest = None
                    best_util = -1
                    for other_host in request.hosts:
                        if other_host.id == host.id:
                            continue
                        
                        available_cpu = temp_hosts[other_host.id]['cpu']
                        available_ram = temp_hosts[other_host.id]['ram']
                        
                        if available_cpu >= vm.cpu_required and available_ram >= vm.ram_required:
                            if best_dest is None or temp_hosts[other_host.id]['util'] > best_util:
                                best_dest = other_host
                                best_util = temp_hosts[other_host.id]['util']
                                
                    if best_dest:
                        temp_hosts[best_dest.id]['cpu'] -= vm.cpu_required
                        temp_hosts[best_dest.id]['ram'] -= vm.ram_required
                        temp_hosts[best_dest.id]['util'] += (vm.cpu_required / best_dest.cpu_capacity * 100)
                        
                        host_migrations.append(MigrationCandidate(
                            vm_id=vm.id,
                            source_host_id=host.id,
                            dest_host_id=best_dest.id,
                            reason="Power consolidation",
                            status="EVALUATED"
                        ))
                    else:
                        evacuation_feasible = False
                        break
                
                if evacuation_feasible:
                    state = "SLEEP_CANDIDATE"
                    migrations = host_migrations
                    reason = "Evacuation feasible. Consolidate workloads to sleep server."
                    action_status = "EVALUATED" 
                else:
                    state = "PROTECTED"
                    recommended_action = "KEEP_ACTIVE"
                    reason = "Evacuation infeasible due to lack of destination capacity."
                    action_status = "PROTECTED"
                    migration_required = False
                    migrations = []

            server_states.append(ServerPowerState(
                server_id=host.id,
                state=state,
                cpu_utilization=host.cpu_utilization,
                ram_utilization=host.ram_utilization,
                active_vms_count=active_vms_count,
                recommended_action=recommended_action,
                migration_required=migration_required,
                migrations=migrations,
                action_status=action_status,
                power_consumption_w=None, 
                energy_savings_kwh=None,
                reason=reason
            ))
            
        return PowerEvaluateResponse(
            server_states=server_states,
            message="Power evaluation completed successfully using deterministic rules.",
            database_persisted=False
        )

power_service = PowerService()
