from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.schemas import HealthResponse, DatabaseHealthResponse
from backend.database import engine, check_db_connection, init_db
from backend.workflow.router import router as workflow_router
from backend.forecasting.router import router as forecast_router
from backend.resources.router import router as resource_router
from backend.scheduling.router import router as scheduling_router
from backend.simulation.router import router as simulation_router
from backend.optimization.router import router as migration_router
from backend.optimization.power_router import router as power_router
from backend.optimization.failure_router import router as failure_router
from backend.dashboard.router import router as dashboard_router
from backend.forecasting.carbon_service import carbon_service
from backend.forecasting.renewable_service import renewable_service
import contextlib

@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="GreenCloud Backend",
    version="0.1.0",
    description="Backend foundation for GreenCloud Data Center project",
    lifespan=lifespan
)

# CORS configuration for local React development
origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(workflow_router, prefix="/api/workflows", tags=["Workflows"])
app.include_router(forecast_router, prefix="/api/forecast", tags=["Forecasting"])
app.include_router(resource_router, prefix="/api/resources", tags=["Resources"])
app.include_router(scheduling_router, prefix="/api/scheduling", tags=["Scheduling"])
app.include_router(simulation_router, prefix="/api/simulation", tags=["Simulation"])
app.include_router(migration_router, prefix="/api/migration", tags=["Migration"])
app.include_router(power_router, prefix="/api/power", tags=["Power Management"])
app.include_router(failure_router, prefix="/api/failure", tags=["Failure Prediction"])
app.include_router(dashboard_router, prefix="/api/dashboard", tags=["Dashboard"])

@app.get("/")
def read_root():
    return {

        "service": "GreenCloud Backend",
        "status": "running",
        "version": "0.1.0"
    }

@app.get("/api/health", response_model=HealthResponse)
def health_check():
    db_status = check_db_connection()
    
    # Determine precise ML status
    if carbon_service.is_loaded and renewable_service.is_loaded:
        ml_status = "operational"
    elif carbon_service.is_loaded or renewable_service.is_loaded:
        ml_status = "partially_operational"
    elif carbon_service.is_configured or renewable_service.is_configured:
        ml_status = "unavailable" # Configured but failed to load
    else:
        ml_status = "not_configured"
    
    return HealthResponse(
        status="healthy",
        backend="operational",
        database=db_status,
        ml_models=ml_status,
        workflowsim="not_configured",
        cloudsim="not_configured"
    )

@app.get("/api/health/database", response_model=DatabaseHealthResponse)
def database_health_check():
    db_status = check_db_connection()
    return DatabaseHealthResponse(database=db_status)



