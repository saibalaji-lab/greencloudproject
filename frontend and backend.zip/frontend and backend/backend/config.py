import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    DATABASE_URL = os.getenv("DATABASE_URL")
    CARBON_MODEL_PATH = os.getenv("CARBON_MODEL_PATH")
    RENEWABLE_MODEL_PATH = os.getenv("RENEWABLE_MODEL_PATH")
    WORKFLOWSIM_PATH = os.getenv("WORKFLOWSIM_PATH")
    CLOUDSIM_PATH = os.getenv("CLOUDSIM_PATH")
    GOOGLE_TRACE_PATH = os.getenv("GOOGLE_TRACE_PATH")
    ALIBABA_TRACE_PATH = os.getenv("ALIBABA_TRACE_PATH")

settings = Settings()
