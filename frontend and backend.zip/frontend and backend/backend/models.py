from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from backend.database import Base

class Workflow(Base):
    __tablename__ = "workflows"
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String(255), nullable=False)
    workflow_name = Column(String(255))
    workflow_type = Column(String(100))
    file_format = Column(String(50))
    file_size = Column(Integer)
    uploaded_at = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String(50), default="uploaded")

    tasks = relationship("WorkflowTask", back_populates="workflow")
    dependencies = relationship("WorkflowDependency", back_populates="workflow")
    clustering_results = relationship("ClusteringResult", back_populates="workflow")
    scheduling_decisions = relationship("SchedulingDecision", back_populates="workflow")
    simulation_runs = relationship("SimulationRun", back_populates="workflow")

class WorkflowTask(Base):
    __tablename__ = "workflow_tasks"
    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, ForeignKey("workflows.id"), nullable=False)
    task_id = Column(String(100), nullable=False)
    task_name = Column(String(255))
    runtime = Column(Float)
    input_size = Column(Float)
    output_size = Column(Float)

    workflow = relationship("Workflow", back_populates="tasks")

class WorkflowDependency(Base):
    __tablename__ = "workflow_dependencies"
    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, ForeignKey("workflows.id"), nullable=False)
    parent_task_id = Column(String(100), nullable=False)
    child_task_id = Column(String(100), nullable=False)

    workflow = relationship("Workflow", back_populates="dependencies")

class ClusteringResult(Base):
    __tablename__ = "clustering_results"
    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, ForeignKey("workflows.id"), nullable=False)
    algorithm = Column(String(100))
    cluster_count = Column(Integer)
    silhouette_score = Column(Float)
    clustering_timestamp = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String(50))

    workflow = relationship("Workflow", back_populates="clustering_results")

class CarbonPrediction(Base):
    __tablename__ = "carbon_predictions"
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    actual_carbon_intensity = Column(Float)
    predicted_carbon_intensity = Column(Float)
    forecast_horizon = Column(Integer)
    model_name = Column(String(100))
    model_version = Column(String(50))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class RenewablePrediction(Base):
    __tablename__ = "renewable_predictions"
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    actual_renewable_generation = Column(Float)
    predicted_renewable_generation = Column(Float)
    forecast_horizon = Column(Integer)
    model_name = Column(String(100))
    model_version = Column(String(50))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class ResourceMetric(Base):
    __tablename__ = "resource_metrics"
    id = Column(Integer, primary_key=True, index=True)
    server_id = Column(String(100), index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    cpu_utilization = Column(Float)
    memory_utilization = Column(Float)
    network_utilization = Column(Float)
    disk_utilization = Column(Float)
    source = Column(String(100))

class SchedulingDecision(Base):
    __tablename__ = "scheduling_decisions"
    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, ForeignKey("workflows.id"))
    task_id = Column(String(100))
    server_id = Column(String(100))
    carbon_intensity = Column(Float)
    renewable_availability = Column(Float)
    scheduling_score = Column(Float)
    decision_reason = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    workflow = relationship("Workflow", back_populates="scheduling_decisions")

class SimulationRun(Base):
    __tablename__ = "simulation_runs"
    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, ForeignKey("workflows.id"))
    simulation_engine = Column(String(100))
    started_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True))
    status = Column(String(50))
    total_tasks = Column(Integer)
    completed_tasks = Column(Integer)
    total_energy = Column(Float)
    total_carbon_emissions = Column(Float)

    workflow = relationship("Workflow", back_populates="simulation_runs")
    migrations = relationship("VMMigration", back_populates="simulation_run")

class VMMigration(Base):
    __tablename__ = "vm_migrations"
    id = Column(Integer, primary_key=True, index=True)
    simulation_run_id = Column(Integer, ForeignKey("simulation_runs.id"))
    vm_id = Column(String(100))
    source_server_id = Column(String(100))
    destination_server_id = Column(String(100))
    reason = Column(Text)
    status = Column(String(50))
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))

    simulation_run = relationship("SimulationRun", back_populates="migrations")

class PowerManagementEvent(Base):
    __tablename__ = "power_management_events"
    id = Column(Integer, primary_key=True, index=True)
    server_id = Column(String(100), index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    cpu_utilization = Column(Float)
    memory_utilization = Column(Float)
    power_consumption = Column(Float)
    action = Column(String(100))
    estimated_power_saving = Column(Float)

class FailurePrediction(Base):
    __tablename__ = "failure_predictions"
    id = Column(Integer, primary_key=True, index=True)
    server_id = Column(String(100), index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    failure_probability = Column(Float)
    anomaly_score = Column(Float)
    failure_reason = Column(Text)
    recommended_action = Column(Text)
    status = Column(String(50))

class SystemHealth(Base):
    __tablename__ = "system_health"
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    backend_status = Column(String(50))
    database_status = Column(String(50))
    ml_status = Column(String(50))
    workflowsim_status = Column(String(50))
    cloudsim_status = Column(String(50))
