import logging
from backend.resources.trace_service import trace_service
from backend.forecasting.carbon_service import carbon_service
from backend.forecasting.renewable_service import renewable_service
from backend.scheduling.schemas import SchedulingRequest, ScoredCandidate, SchedulingResponse, SchedulingStatusResponse

logger = logging.getLogger(__name__)

class SchedulerService:
    def __init__(self):
        pass

    def get_status(self) -> SchedulingStatusResponse:
        return SchedulingStatusResponse(
            scheduler_operational=True,
            google_trace_available=trace_service.is_available("google"),
            alibaba_trace_available=trace_service.is_available("alibaba"),
            carbon_service_available=carbon_service.is_configured and carbon_service.is_loaded,
            renewable_service_available=renewable_service.is_configured and renewable_service.is_loaded,
            database_persistence_available=True # Overridden at router level if DB is None
        )

    def select_server(self, req: SchedulingRequest) -> SchedulingResponse:
        candidates_data = trace_service.get_candidate_servers(source=req.source, limit=req.candidate_limit)
        
        scored_candidates = []
        best_server = None
        best_score = float('-inf')
        
        c_intensity = req.carbon_intensity
        r_gen = req.renewable_generation
        
        # Scoring logic: Higher score is better.
        # Score = w_cpu * (100 - CPU) + w_mem * (100 - Mem) - w_carbon * Carbon + w_renewable * Renewable
        
        for cand in candidates_data:
            sid = cand["server_id"]
            cpu = cand.get("cpu_utilization")
            mem = cand.get("memory_utilization")
            
            rejected = False
            rejection_reason = None
            score = None
            
            if cpu is None and mem is None:
                rejected = True
                rejection_reason = "Missing both CPU and Memory utilization data"
            elif cpu is not None and cpu > req.cpu_threshold:
                rejected = True
                rejection_reason = f"CPU utilization ({cpu:.2f}) exceeds threshold ({req.cpu_threshold})"
            elif mem is not None and mem > req.memory_threshold:
                rejected = True
                rejection_reason = f"Memory utilization ({mem:.2f}) exceeds threshold ({req.memory_threshold})"
            else:
                # Calculate score
                # Note: if cpu or mem is missing, we only score the available one.
                # We do not replace missing with zero.
                score = 0.0
                if cpu is not None:
                    # assuming CPU is a percentage (0-100) or decimal (0-1). 
                    # If it's decimal, normalize to percentage for scoring intuition
                    norm_cpu = cpu if cpu > 1.0 else cpu * 100.0
                    score += req.weights.cpu_weight * (100.0 - norm_cpu)
                if mem is not None:
                    norm_mem = mem if mem > 1.0 else mem * 100.0
                    score += req.weights.memory_weight * (100.0 - norm_mem)
                
                if c_intensity is not None:
                    score -= req.weights.carbon_weight * c_intensity
                
                if r_gen is not None:
                    score += req.weights.renewable_weight * r_gen
                    
                if score > best_score:
                    best_score = score
                    best_server = sid
            
            scored_candidates.append(
                ScoredCandidate(
                    server_id=sid,
                    cpu_utilization=cpu,
                    memory_utilization=mem,
                    score=score,
                    rejected=rejected,
                    rejection_reason=rejection_reason
                )
            )
            
        decision_reason = "No valid candidate found."
        if best_server:
            decision_reason = f"Selected server {best_server} with highest scheduling score of {best_score:.2f}."
            
        return SchedulingResponse(
            task_id=req.task_id,
            selected_server_id=best_server,
            candidates_evaluated=len(scored_candidates),
            candidate_scores=scored_candidates,
            decision_reason=decision_reason,
            carbon_intensity_used=c_intensity,
            renewable_generation_used=r_gen,
            database_persisted=False # Overridden at router level
        )

scheduler_service = SchedulerService()
