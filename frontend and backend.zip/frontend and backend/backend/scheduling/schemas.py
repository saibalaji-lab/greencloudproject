from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class CandidateServer(BaseModel):
    server_id: str
    cpu_utilization: Optional[float] = None
    memory_utilization: Optional[float] = None

class SchedulingWeights(BaseModel):
    cpu_weight: float = 1.0
    memory_weight: float = 1.0
    carbon_weight: float = 1.0
    renewable_weight: float = 1.0

class SchedulingRequest(BaseModel):
    workflow_id: Optional[int] = None
    task_id: str
    source: str = Field(..., description="'google' or 'alibaba'")
    candidate_limit: int = 50
    cpu_threshold: float = 90.0
    memory_threshold: float = 90.0
    weights: SchedulingWeights
    carbon_intensity: Optional[float] = None
    renewable_generation: Optional[float] = None
    persist_decision: bool = False

class ScoredCandidate(BaseModel):
    server_id: str
    cpu_utilization: Optional[float]
    memory_utilization: Optional[float]
    score: Optional[float]
    rejected: bool
    rejection_reason: Optional[str]

class SchedulingResponse(BaseModel):
    task_id: str
    selected_server_id: Optional[str]
    candidates_evaluated: int
    candidate_scores: List[ScoredCandidate]
    decision_reason: str
    carbon_intensity_used: Optional[float]
    renewable_generation_used: Optional[float]
    database_persisted: bool

class SchedulingStatusResponse(BaseModel):
    scheduler_operational: bool
    google_trace_available: bool
    alibaba_trace_available: bool
    carbon_service_available: bool
    renewable_service_available: bool
    database_persistence_available: bool
