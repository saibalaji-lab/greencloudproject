from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from backend.database import engine, get_db
from backend.models import SchedulingDecision
from backend.scheduling.schemas import SchedulingRequest, SchedulingResponse, SchedulingStatusResponse
from backend.scheduling.scheduler_service import scheduler_service
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

def get_db_optional():
    if engine is not None:
        try:
            db = next(get_db())
            yield db
        except Exception:
            yield None
        finally:
            if 'db' in locals() and db is not None:
                db.close()
    else:
        yield None

@router.get("/status", response_model=SchedulingStatusResponse)
def get_scheduling_status(db: Session = Depends(get_db_optional)):
    status = scheduler_service.get_status()
    status.database_persistence_available = (db is not None)
    return status

@router.post("/select", response_model=SchedulingResponse)
def select_server(request: SchedulingRequest, db: Session = Depends(get_db_optional)):
    try:
        response = scheduler_service.select_server(request)
    except Exception as e:
        logger.error(f"Scheduling selection failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
        
    db_persisted = False
    
    if request.persist_decision and response.selected_server_id:
        if db is not None:
            try:
                # Find the score of the selected server
                best_score = None
                for cand in response.candidate_scores:
                    if cand.server_id == response.selected_server_id:
                        best_score = cand.score
                        break
                        
                decision_record = SchedulingDecision(
                    workflow_id=request.workflow_id,
                    task_id=request.task_id,
                    server_id=response.selected_server_id,
                    carbon_intensity=response.carbon_intensity_used,
                    renewable_availability=response.renewable_generation_used,
                    scheduling_score=best_score,
                    decision_reason=response.decision_reason
                )
                db.add(decision_record)
                db.commit()
                db_persisted = True
            except Exception as e:
                db.rollback()
                logger.error(f"Failed to persist scheduling decision to DB: {e}")
                
    response.database_persisted = db_persisted
    return response
