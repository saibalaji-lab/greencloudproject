from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from backend.database import engine, get_db
from backend.models import ResourceMetric
from backend.resources.schemas import TraceStatusResponse, TraceSummaryRequest, TraceSummaryResponse
from backend.resources.trace_service import trace_service
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

def get_db_optional():
    if engine is not None:
        try:
            db = next(get_db())
            yield db
        except Exception:
            yield None
        finally:
            if 'db' in locals() and db is not None:
                db.close()
    else:
        yield None

@router.get("/status", response_model=TraceStatusResponse)
def get_trace_status(db: Session = Depends(get_db_optional)):
    return TraceStatusResponse(
        google_trace_configured=trace_service.is_configured("google"),
        alibaba_trace_configured=trace_service.is_configured("alibaba"),
        google_trace_available=trace_service.is_available("google"),
        alibaba_trace_available=trace_service.is_available("alibaba"),
        database_persistence_available=(db is not None)
    )

@router.post("/summary", response_model=TraceSummaryResponse)
def get_trace_summary(request: TraceSummaryRequest, db: Session = Depends(get_db_optional)):
    if request.source not in ["google", "alibaba"]:
        raise HTTPException(status_code=400, detail="Invalid source. Must be 'google' or 'alibaba'.")
        
    if not trace_service.is_configured(request.source):
        raise HTTPException(status_code=503, detail=f"{request.source.capitalize()} trace is not configured.")
        
    if not trace_service.is_available(request.source):
        raise HTTPException(status_code=503, detail=f"{request.source.capitalize()} trace file is not available at the configured path.")
        
    try:
        summary = trace_service.process_summary(
            source=request.source,
            server_id=request.server_id,
            start_time=request.start_timestamp,
            end_time=request.end_timestamp
        )
    except Exception as e:
        logger.error(f"Error calculating trace summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))
        
    db_persisted = False
    msg = "Summary generated successfully."
    
    if request.persist_summary:
        if db is not None:
            try:
                # Store aggregated metric row to represent the summary mapping
                metric = ResourceMetric(
                    server_id=request.server_id or "AGGREGATED",
                    timestamp=summary["time_range_end"] or datetime.utcnow(),
                    cpu_utilization=summary["avg_cpu_utilization"],
                    memory_utilization=summary["avg_memory_utilization"],
                    source=request.source
                )
                db.add(metric)
                db.commit()
                db_persisted = True
                msg += " Aggregated metrics persisted to database."
            except Exception as e:
                db.rollback()
                logger.error(f"Failed to persist trace summary to DB: {e}")
                msg += " Failed to persist to database."
        else:
            msg += " Database is unavailable; persistence skipped."

    return TraceSummaryResponse(
        source=summary["source"],
        server_count=summary["server_count"],
        observation_count=summary["observation_count"],
        time_range_start=summary["time_range_start"],
        time_range_end=summary["time_range_end"],
        avg_cpu_utilization=summary["avg_cpu_utilization"],
        avg_memory_utilization=summary["avg_memory_utilization"],
        min_cpu_utilization=summary["min_cpu_utilization"],
        max_cpu_utilization=summary["max_cpu_utilization"],
        min_memory_utilization=summary["min_memory_utilization"],
        max_memory_utilization=summary["max_memory_utilization"],
        database_persisted=db_persisted,
        message=msg
    )
