import pandas as pd
import os
import logging
from backend.config import settings

logger = logging.getLogger(__name__)

class TraceService:
    def __init__(self):
        self.google_path = settings.GOOGLE_TRACE_PATH
        self.alibaba_path = settings.ALIBABA_TRACE_PATH

    def is_configured(self, source: str) -> bool:
        if source == "google":
            return bool(self.google_path)
        elif source == "alibaba":
            return bool(self.alibaba_path)
        return False

    def is_available(self, source: str) -> bool:
        if source == "google" and self.google_path:
            return os.path.exists(self.google_path)
        if source == "alibaba" and self.alibaba_path:
            return os.path.exists(self.alibaba_path)
        return False

    def process_summary(self, source: str, server_id=None, start_time=None, end_time=None):
        path = self.google_path if source == "google" else self.alibaba_path
        if not path or not os.path.exists(path):
            raise ValueError(f"Trace for {source} not found at configured path.")

        # Chunked reading to prevent OOM
        chunk_size = 50000
        
        total_obs = 0
        servers = set()
        
        cpu_sum = 0.0
        mem_sum = 0.0
        cpu_count = 0
        mem_count = 0
        
        min_cpu = float('inf')
        max_cpu = float('-inf')
        min_mem = float('inf')
        max_mem = float('-inf')
        
        global_start = None
        global_end = None
        
        try:
            for chunk in pd.read_csv(path, chunksize=chunk_size, iterator=True, on_bad_lines='skip'):
                # Normalize column names 
                cols = [c.lower().strip() for c in chunk.columns]
                chunk.columns = cols
                
                # Column mapping heuristics
                time_col = None
                server_col = None
                cpu_col = None
                mem_col = None
                
                if source == "alibaba":
                    time_col = 'time_stamp' if 'time_stamp' in cols else ('timestamp' if 'timestamp' in cols else None)
                    server_col = 'machine_id' if 'machine_id' in cols else ('server_id' if 'server_id' in cols else None)
                    cpu_col = 'cpu_util_percent' if 'cpu_util_percent' in cols else ('cpu' if 'cpu' in cols else None)
                    mem_col = 'mem_util_percent' if 'mem_util_percent' in cols else ('memory' if 'memory' in cols else None)
                elif source == "google":
                    time_col = 'start_time' if 'start_time' in cols else ('timestamp' if 'timestamp' in cols else None)
                    server_col = 'machine_id' if 'machine_id' in cols else ('server_id' if 'server_id' in cols else None)
                    cpu_col = 'cpu_rate' if 'cpu_rate' in cols else ('cpu' if 'cpu' in cols else None)
                    mem_col = 'canonical_memory_usage' if 'canonical_memory_usage' in cols else ('memory' if 'memory' in cols else None)
                
                if not time_col and not server_col:
                    continue # Cannot process this chunk
                    
                if time_col and chunk[time_col].dtype == 'O': 
                    chunk[time_col] = pd.to_datetime(chunk[time_col], errors='coerce')
                elif time_col and pd.api.types.is_numeric_dtype(chunk[time_col]):
                    # Handle unix timestamps appropriately (e.g., s)
                    chunk[time_col] = pd.to_datetime(chunk[time_col], unit='s', errors='coerce')
                
                # Apply filters
                if server_id and server_col:
                    chunk = chunk[chunk[server_col].astype(str) == str(server_id)]
                if start_time and time_col:
                    chunk = chunk[chunk[time_col] >= pd.to_datetime(start_time)]
                if end_time and time_col:
                    chunk = chunk[chunk[time_col] <= pd.to_datetime(end_time)]
                    
                if chunk.empty:
                    continue
                    
                total_obs += len(chunk)
                if server_col:
                    servers.update(chunk[server_col].dropna().unique())
                if time_col:
                    valid_times = chunk[time_col].dropna()
                    if not valid_times.empty:
                        c_min = valid_times.min()
                        c_max = valid_times.max()
                        global_start = min(global_start, c_min) if global_start else c_min
                        global_end = max(global_end, c_max) if global_end else c_max
                        
                if cpu_col:
                    valid_cpu = pd.to_numeric(chunk[cpu_col], errors='coerce').dropna()
                    if not valid_cpu.empty:
                        cpu_sum += valid_cpu.sum()
                        cpu_count += len(valid_cpu)
                        min_cpu = min(min_cpu, valid_cpu.min())
                        max_cpu = max(max_cpu, valid_cpu.max())
                        
                if mem_col:
                    valid_mem = pd.to_numeric(chunk[mem_col], errors='coerce').dropna()
                    if not valid_mem.empty:
                        mem_sum += valid_mem.sum()
                        mem_count += len(valid_mem)
                        min_mem = min(min_mem, valid_mem.min())
                        max_mem = max(max_mem, valid_mem.max())

        except Exception as e:
            logger.error(f"Error processing trace {source}: {e}")
            raise RuntimeError(f"Failed to process trace file: {e}")
            
        return {
            "source": source,
            "server_count": len(servers),
            "observation_count": total_obs,
            "time_range_start": global_start,
            "time_range_end": global_end,
            "avg_cpu_utilization": float(cpu_sum / cpu_count) if cpu_count > 0 else None,
            "avg_memory_utilization": float(mem_sum / mem_count) if mem_count > 0 else None,
            "min_cpu_utilization": float(min_cpu) if min_cpu != float('inf') else None,
            "max_cpu_utilization": float(max_cpu) if max_cpu != float('-inf') else None,
            "min_memory_utilization": float(min_mem) if min_mem != float('inf') else None,
            "max_memory_utilization": float(max_mem) if max_mem != float('-inf') else None,
        }

    def get_candidate_servers(self, source: str, limit: int = 50) -> list[dict]:
        path = self.google_path if source == "google" else self.alibaba_path
        if not path or not os.path.exists(path):
            raise ValueError(f"Trace for {source} not found at configured path.")

        candidates = {}
        try:
            # Only read the first chunk to get a sample of active servers
            chunk_iter = pd.read_csv(path, chunksize=10000, iterator=True, on_bad_lines='skip')
            for chunk in chunk_iter:
                cols = [c.lower().strip() for c in chunk.columns]
                chunk.columns = cols
                
                server_col = None
                cpu_col = None
                mem_col = None
                
                if source == "alibaba":
                    server_col = 'machine_id' if 'machine_id' in cols else ('server_id' if 'server_id' in cols else None)
                    cpu_col = 'cpu_util_percent' if 'cpu_util_percent' in cols else ('cpu' if 'cpu' in cols else None)
                    mem_col = 'mem_util_percent' if 'mem_util_percent' in cols else ('memory' if 'memory' in cols else None)
                elif source == "google":
                    server_col = 'machine_id' if 'machine_id' in cols else ('server_id' if 'server_id' in cols else None)
                    cpu_col = 'cpu_rate' if 'cpu_rate' in cols else ('cpu' if 'cpu' in cols else None)
                    mem_col = 'canonical_memory_usage' if 'canonical_memory_usage' in cols else ('memory' if 'memory' in cols else None)
                
                if not server_col:
                    break
                    
                # Get the most recent observation for each server in the chunk
                for _, row in chunk.iterrows():
                    sid = str(row[server_col]) if pd.notna(row[server_col]) else None
                    if not sid:
                        continue
                        
                    if sid not in candidates:
                        cpu_val = float(row[cpu_col]) if cpu_col and pd.notna(row[cpu_col]) else None
                        mem_val = float(row[mem_col]) if mem_col and pd.notna(row[mem_col]) else None
                        candidates[sid] = {
                            "server_id": sid,
                            "cpu_utilization": cpu_val,
                            "memory_utilization": mem_val
                        }
                    
                    if len(candidates) >= limit:
                        break
                
                if len(candidates) >= limit:
                    break

        except Exception as e:
            logger.error(f"Error fetching candidates for {source}: {e}")
            
        return list(candidates.values())

trace_service = TraceService()
