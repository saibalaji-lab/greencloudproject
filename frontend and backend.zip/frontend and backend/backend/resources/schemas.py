from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class TraceStatusResponse(BaseModel):
    google_trace_configured: bool
    alibaba_trace_configured: bool
    google_trace_available: bool
    alibaba_trace_available: bool
    database_persistence_available: bool

class TraceSummaryRequest(BaseModel):
    source: str
    server_id: Optional[str] = None
    start_timestamp: Optional[datetime] = None
    end_timestamp: Optional[datetime] = None
    persist_summary: bool = False

class TraceSummaryResponse(BaseModel):
    source: str
    server_count: int
    observation_count: int
    time_range_start: Optional[datetime]
    time_range_end: Optional[datetime]
    avg_cpu_utilization: Optional[float]
    avg_memory_utilization: Optional[float]
    min_cpu_utilization: Optional[float]
    max_cpu_utilization: Optional[float]
    min_memory_utilization: Optional[float]
    max_memory_utilization: Optional[float]
    database_persisted: bool
    message: str
