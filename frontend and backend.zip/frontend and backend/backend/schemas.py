from pydantic import BaseModel

class HealthResponse(BaseModel):
    status: str
    backend: str
    database: str
    ml_models: str
    workflowsim: str
    cloudsim: str

class DatabaseHealthResponse(BaseModel):
    database: str
