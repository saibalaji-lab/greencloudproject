import time
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session
from sqlalchemy.sql import func

from backend.models import (
    Workflow, WorkflowTask, CarbonPrediction, RenewablePrediction,
    ResourceMetric, SchedulingDecision, SimulationRun, VMMigration,
    PowerManagementEvent, FailurePrediction, SystemHealth
)
from backend.dashboard.schemas import (
    MetricValue, WorkflowSummary, CarbonSummary, RenewableSummary,
    ResourceSummary, SchedulingSummary, SimulationSummary, MigrationSummary,
    PowerSummary, FailureSummary, SustainabilitySummary, DashboardSummaryResponse,
    SystemHealthResponse
)

# Keep track of process uptime
START_TIME = time.time()

class DashboardService:
    def get_summary(self, db: Optional[Session]) -> DashboardSummaryResponse:
        if db is None:
            unavailable_metric = MetricValue(available=False, reason="Database unavailable")
            return DashboardSummaryResponse(
                workflow=WorkflowSummary(total_workflows=unavailable_metric, total_tasks=unavailable_metric),
                carbon=CarbonSummary(total_predictions=unavailable_metric, latest_prediction=unavailable_metric),
                renewable=RenewableSummary(total_predictions=unavailable_metric, latest_prediction=unavailable_metric),
                resources=ResourceSummary(total_observations=unavailable_metric, unique_servers=unavailable_metric),
                scheduling=SchedulingSummary(total_decisions=unavailable_metric, carbon_aware_decisions=unavailable_metric),
                simulation=SimulationSummary(total_runs=unavailable_metric, successful_runs=unavailable_metric),
                migration=MigrationSummary(total_migrations=unavailable_metric, successful_migrations=unavailable_metric),
                power=PowerSummary(total_events=unavailable_metric, sleep_candidates=unavailable_metric, dvfs_recommendations=unavailable_metric),
                failure=FailureSummary(total_predictions=unavailable_metric, high_critical_risk_events=unavailable_metric, self_healing_blocked=unavailable_metric),
                sustainability=SustainabilitySummary(carbon_reduction=unavailable_metric, energy_savings=unavailable_metric),
                message="Dashboard unavailable due to missing database connection."
            )
        
        try:
            # Workflow
            wf_count = db.query(func.count(Workflow.id)).scalar() or 0
            task_count = db.query(func.count(WorkflowTask.id)).scalar() or 0
            
            # Carbon
            carb_count = db.query(func.count(CarbonPrediction.id)).scalar() or 0
            latest_carb = db.query(CarbonPrediction).order_by(CarbonPrediction.id.desc()).first()
            latest_carb_val = latest_carb.predicted_carbon_intensity if latest_carb else None
            
            # Renewable
            ren_count = db.query(func.count(RenewablePrediction.id)).scalar() or 0
            latest_ren = db.query(RenewablePrediction).order_by(RenewablePrediction.id.desc()).first()
            latest_ren_val = latest_ren.predicted_renewable_generation if latest_ren else None
            
            # Resources
            res_count = db.query(func.count(ResourceMetric.id)).scalar() or 0
            srv_count = db.query(func.count(func.distinct(ResourceMetric.server_id))).scalar() or 0
            
            # Scheduling
            sched_count = db.query(func.count(SchedulingDecision.id)).scalar() or 0
            
            # Simulation
            sim_count = db.query(func.count(SimulationRun.id)).scalar() or 0
            sim_succ = db.query(func.count(SimulationRun.id)).filter(SimulationRun.status == "SUCCESS").scalar() or 0
            
            # Migration
            mig_count = db.query(func.count(VMMigration.id)).scalar() or 0
            mig_succ = db.query(func.count(VMMigration.id)).filter(VMMigration.status == "SUCCESS").scalar() or 0
            
            # Power
            pow_count = db.query(func.count(PowerManagementEvent.id)).scalar() or 0
            pow_sleep = db.query(func.count(PowerManagementEvent.id)).filter(PowerManagementEvent.action.like("%SLEEP%")).scalar() or 0
            pow_dvfs = db.query(func.count(PowerManagementEvent.id)).filter(PowerManagementEvent.action.like("%DVFS%")).scalar() or 0
            
            # Failure
            fail_count = db.query(func.count(FailurePrediction.id)).scalar() or 0
            fail_high = db.query(func.count(FailurePrediction.id)).filter(FailurePrediction.anomaly_score > 0.6).scalar() or 0
            fail_blocked = db.query(func.count(FailurePrediction.id)).filter(FailurePrediction.status == "RECOVERY_BLOCKED").scalar() or 0
            
            return DashboardSummaryResponse(
                workflow=WorkflowSummary(
                    total_workflows=MetricValue(available=True, value=wf_count),
                    total_tasks=MetricValue(available=True, value=task_count)
                ),
                carbon=CarbonSummary(
                    total_predictions=MetricValue(available=True, value=carb_count),
                    latest_prediction=MetricValue(available=(latest_carb_val is not None), value=latest_carb_val)
                ),
                renewable=RenewableSummary(
                    total_predictions=MetricValue(available=True, value=ren_count),
                    latest_prediction=MetricValue(available=(latest_ren_val is not None), value=latest_ren_val)
                ),
                resources=ResourceSummary(
                    total_observations=MetricValue(available=True, value=res_count),
                    unique_servers=MetricValue(available=True, value=srv_count)
                ),
                scheduling=SchedulingSummary(
                    total_decisions=MetricValue(available=True, value=sched_count),
                    carbon_aware_decisions=MetricValue(available=True, value=sched_count)
                ),
                simulation=SimulationSummary(
                    total_runs=MetricValue(available=True, value=sim_count),
                    successful_runs=MetricValue(available=True, value=sim_succ)
                ),
                migration=MigrationSummary(
                    total_migrations=MetricValue(available=True, value=mig_count),
                    successful_migrations=MetricValue(available=True, value=mig_succ)
                ),
                power=PowerSummary(
                    total_events=MetricValue(available=True, value=pow_count),
                    sleep_candidates=MetricValue(available=True, value=pow_sleep),
                    dvfs_recommendations=MetricValue(available=True, value=pow_dvfs)
                ),
                failure=FailureSummary(
                    total_predictions=MetricValue(available=True, value=fail_count),
                    high_critical_risk_events=MetricValue(available=True, value=fail_high),
                    self_healing_blocked=MetricValue(available=True, value=fail_blocked)
                ),
                sustainability=SustainabilitySummary(
                    carbon_reduction=MetricValue(available=False, value=None, reason="Baseline information unavailable to perform valid calculation."),
                    energy_savings=MetricValue(available=False, value=None, reason="CloudSim power model is currently unavailable.")
                ),
                message="Dashboard aggregation complete."
            )
        except Exception as e:
            err_metric = MetricValue(available=False, reason=f"Aggregation error: {e}")
            return DashboardSummaryResponse(
                workflow=WorkflowSummary(total_workflows=err_metric, total_tasks=err_metric),
                carbon=CarbonSummary(total_predictions=err_metric, latest_prediction=err_metric),
                renewable=RenewableSummary(total_predictions=err_metric, latest_prediction=err_metric),
                resources=ResourceSummary(total_observations=err_metric, unique_servers=err_metric),
                scheduling=SchedulingSummary(total_decisions=err_metric, carbon_aware_decisions=err_metric),
                simulation=SimulationSummary(total_runs=err_metric, successful_runs=err_metric),
                migration=MigrationSummary(total_migrations=err_metric, successful_migrations=err_metric),
                power=PowerSummary(total_events=err_metric, sleep_candidates=err_metric, dvfs_recommendations=err_metric),
                failure=FailureSummary(total_predictions=err_metric, high_critical_risk_events=err_metric, self_healing_blocked=err_metric),
                sustainability=SustainabilitySummary(carbon_reduction=err_metric, energy_savings=err_metric),
                message=f"Error retrieving dashboard metrics: {e}"
            )

    def get_health(self, db: Optional[Session]) -> SystemHealthResponse:
        uptime = time.time() - START_TIME
        
        database_metric = MetricValue(available=(db is not None), value="operational" if db else "unavailable", reason="MySQL connection check")
        
        modules = {}
        
        # Check CloudSim
        try:
            from backend.simulation.cloudsim_service import cloudsim_service
            cs_status = cloudsim_service.get_status()
            if cs_status.get("simulation_service_available"):
                modules["cloudsim"] = MetricValue(available=True, value="operational")
            else:
                modules["cloudsim"] = MetricValue(available=False, value="unavailable", reason="Java or JAR not found")
        except Exception as e:
            modules["cloudsim"] = MetricValue(available=False, value="unavailable", reason=str(e))
            
        # Check Models
        try:
            from backend.ai_models.carbon_model import CarbonModelService
            if CarbonModelService()._model is not None:
                modules["carbon_forecast"] = MetricValue(available=True, value="operational")
            else:
                modules["carbon_forecast"] = MetricValue(available=False, value="not_configured", reason="Model file missing")
        except Exception as e:
            modules["carbon_forecast"] = MetricValue(available=False, value="unavailable", reason=str(e))
            
        # Optimization services (Assume operational if python imports work)
        try:
            from backend.optimization.migration_service import migration_service
            modules["migration"] = MetricValue(available=True, value="operational")
        except Exception as e:
            modules["migration"] = MetricValue(available=False, value="unavailable", reason=str(e))
            
        try:
            from backend.optimization.power_service import power_service
            modules["power"] = MetricValue(available=True, value="operational", reason="Rule-based deterministic engine")
        except Exception as e:
            modules["power"] = MetricValue(available=False, value="unavailable", reason=str(e))
            
        try:
            from backend.optimization.failure_service import failure_service
            modules["failure"] = MetricValue(available=True, value="operational", reason="Statistical anomaly detector")
        except Exception as e:
            modules["failure"] = MetricValue(available=False, value="unavailable", reason=str(e))
            
        overall_status = "operational" if database_metric.available else "partially_operational"
        
        # Optional: Save to db if needed
        if db is not None:
            try:
                sys_health = SystemHealth(
                    backend_status=overall_status,
                    database_status=database_metric.value,
                    ml_status=modules.get("carbon_forecast", MetricValue(available=False)).value,
                    cloudsim_status=modules.get("cloudsim", MetricValue(available=False)).value
                )
                db.add(sys_health)
                db.commit()
            except Exception:
                db.rollback()

        return SystemHealthResponse(
            uptime_seconds=MetricValue(available=True, value=uptime, source="backend_process_uptime"),
            database=database_metric,
            modules=modules,
            overall_status=overall_status
        )

dashboard_service = DashboardService()
