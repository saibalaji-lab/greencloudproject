from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import Optional

from backend.database import engine, get_db
from backend.dashboard.schemas import DashboardSummaryResponse, SystemHealthResponse
from backend.dashboard.service import dashboard_service

router = APIRouter()

def get_db_optional():
    if engine is not None:
        try:
            db = next(get_db())
            yield db
        except Exception:
            yield None
        finally:
            if 'db' in locals() and db is not None:
                db.close()
    else:
        yield None

@router.get("/summary", response_model=DashboardSummaryResponse)
def get_dashboard_summary(db: Session = Depends(get_db_optional)):
    """
    Retrieves the aggregated dashboard sustainability metrics truthfully based on actual records.
    Does NOT calculate false carbon reduction or fake energy savings.
    """
    return dashboard_service.get_summary(db)

@router.get("/health", response_model=SystemHealthResponse)
def get_system_health(db: Session = Depends(get_db_optional)):
    """
    Retrieves system uptime and component availability dynamically.
    """
    return dashboard_service.get_health(db)
