from pydantic import BaseModel
from typing import Any, Optional, Dict, List

class MetricValue(BaseModel):
    available: bool
    value: Any = None
    reason: Optional[str] = None
    source: Optional[str] = None
    timestamp: Optional[str] = None

class WorkflowSummary(BaseModel):
    total_workflows: MetricValue
    total_tasks: MetricValue

class CarbonSummary(BaseModel):
    total_predictions: MetricValue
    latest_prediction: MetricValue

class RenewableSummary(BaseModel):
    total_predictions: MetricValue
    latest_prediction: MetricValue

class ResourceSummary(BaseModel):
    total_observations: MetricValue
    unique_servers: MetricValue

class SchedulingSummary(BaseModel):
    total_decisions: MetricValue
    carbon_aware_decisions: MetricValue

class SimulationSummary(BaseModel):
    total_runs: MetricValue
    successful_runs: MetricValue

class MigrationSummary(BaseModel):
    total_migrations: MetricValue
    successful_migrations: MetricValue

class PowerSummary(BaseModel):
    total_events: MetricValue
    sleep_candidates: MetricValue
    dvfs_recommendations: MetricValue

class FailureSummary(BaseModel):
    total_predictions: MetricValue
    high_critical_risk_events: MetricValue
    self_healing_blocked: MetricValue

class SustainabilitySummary(BaseModel):
    carbon_reduction: MetricValue
    energy_savings: MetricValue

class DashboardSummaryResponse(BaseModel):
    workflow: WorkflowSummary
    carbon: CarbonSummary
    renewable: RenewableSummary
    resources: ResourceSummary
    scheduling: SchedulingSummary
    simulation: SimulationSummary
    migration: MigrationSummary
    power: PowerSummary
    failure: FailureSummary
    sustainability: SustainabilitySummary
    message: str

class SystemHealthResponse(BaseModel):
    uptime_seconds: MetricValue
    database: MetricValue
    modules: Dict[str, MetricValue]
    overall_status: str
