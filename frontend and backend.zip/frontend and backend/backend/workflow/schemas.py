from pydantic import BaseModel
from typing import Optional, List

class WorkflowUploadResponse(BaseModel):
    workflow_id: Optional[int] = None
    filename: str
    workflow_name: Optional[str]
    file_format: str
    file_size: int
    task_count: int
    dependency_count: int
    status: str
    database_persisted: bool
    message: Optional[str] = None

class ClusterDistribution(BaseModel):
    cluster_label: int
    task_count: int
    percentage: float

class ClusteringResponse(BaseModel):
    workflow_id: int
    algorithm: str
    selected_k: int
    silhouette_score: float
    davies_bouldin_score: float
    task_count: int
    cluster_distribution: List[ClusterDistribution]
    features_used: List[str]
    status: str

