from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from sqlalchemy.orm import Session
from backend.database import get_db, engine
from backend.workflow.schemas import WorkflowUploadResponse, ClusteringResponse
from backend.workflow.parser import parse_workflow_xml, WorkflowParseError
from backend.workflow.service import store_parsed_workflow, cluster_workflow_tasks
import logging
import os

logger = logging.getLogger(__name__)
router = APIRouter()

MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB limit

# Safely yield a DB connection without crashing if DB is unconfigured
def get_db_optional():
    if engine is not None:
        try:
            db = next(get_db())
            yield db
        except Exception:
            yield None
        finally:
            if 'db' in locals() and db is not None:
                db.close()
    else:
        yield None

@router.post("/upload", response_model=WorkflowUploadResponse)
async def upload_workflow(file: UploadFile = File(...), db: Session = Depends(get_db_optional)):
    filename = file.filename or "unknown"
    ext = os.path.splitext(filename)[1].lower()
    
    if ext not in [".xml", ".dax"]:
        raise HTTPException(status_code=400, detail="Unsupported file extension. Only .xml and .dax are allowed.")
        
    content = await file.read(MAX_FILE_SIZE + 1)
    file_size = len(content)
    
    if file_size == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
    if file_size > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail=f"File exceeds maximum allowed size of {MAX_FILE_SIZE // (1024*1024)}MB.")
        
    # 1. Parsing
    try:
        parsed_data = parse_workflow_xml(content, filename)
    except WorkflowParseError as e:
        raise HTTPException(status_code=400, detail=str(e))
        
    task_count = len(parsed_data["tasks"])
    dependency_count = len(parsed_data["dependencies"])
    
    # 2. Database Persistence
    workflow_id = None
    db_persisted = False
    status = "parsed"
    msg = "Workflow parsed successfully."
    
    if db is not None:
        try:
            workflow_id = store_parsed_workflow(db, parsed_data, filename, ext, file_size)
            db_persisted = True
            status = "stored"
            msg = "Workflow parsed and stored in database successfully."
        except Exception as e:
            logger.error(f"Failed to store workflow in DB: {e}")
            raise HTTPException(status_code=500, detail="Database persistence failed. Try again or check server logs.")
    else:
        msg = "Workflow parsed successfully. Database not configured; persistence skipped."
        
    return WorkflowUploadResponse(
        workflow_id=workflow_id,
        filename=filename,
        workflow_name=parsed_data.get("workflow_name"),
        file_format=ext,
        file_size=file_size,
        task_count=task_count,
        dependency_count=dependency_count,
        status=status,
        database_persisted=db_persisted,
        message=msg
    )

@router.post("/{workflow_id}/cluster", response_model=ClusteringResponse)
async def cluster_workflow(workflow_id: int, db: Session = Depends(get_db_optional)):
    if db is None:
        raise HTTPException(
            status_code=503, 
            detail="Database is not configured. Real task clustering requires the database."
        )
        
    try:
        result = cluster_workflow_tasks(db, workflow_id)
        
        # Format the response mapping
        return ClusteringResponse(
            workflow_id=workflow_id,
            algorithm=result["algorithm"],
            selected_k=result["selected_k"],
            silhouette_score=result["silhouette_score"],
            davies_bouldin_score=result["davies_bouldin_score"],
            task_count=result["task_count"],
            cluster_distribution=result["cluster_distribution"],
            features_used=result["features_used"],
            status="success"
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Clustering error: {e}")
        raise HTTPException(status_code=500, detail="An error occurred during clustering.")

