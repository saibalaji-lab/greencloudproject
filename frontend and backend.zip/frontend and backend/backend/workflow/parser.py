import xml.etree.ElementTree as ET
import re

class WorkflowParseError(Exception):
    pass

def parse_workflow_xml(xml_content: bytes, filename: str) -> dict:
    # Safely guard against basic XML External Entity (XXE) expansion by denying DOCTYPE/ENTITY definitions
    if b"<!DOCTYPE" in xml_content or b"<!ENTITY" in xml_content:
        raise WorkflowParseError("XML containing DOCTYPE or ENTITY declarations is not allowed for security reasons.")
    
    try:
        root = ET.fromstring(xml_content)
    except ET.ParseError as e:
        raise WorkflowParseError(f"Malformed XML: {e}")
        
    ns = ""
    if root.tag.endswith('adag'):
        m = re.match(r'\{.*\}', root.tag)
        if m:
            ns = m.group(0)

    workflow_name = root.attrib.get("name", "Unknown Workflow")
    
    tasks = []
    dependencies = []
    
    # Extract Jobs/Tasks
    for job in root.findall(f".//{ns}job") + root.findall(f".//{ns}task"):
        task_id = job.attrib.get("id")
        if not task_id:
            continue
            
        task_name = job.attrib.get("name")
        
        # Runtime extraction (optional)
        runtime_str = job.attrib.get("runtime")
        try:
            runtime = float(runtime_str) if runtime_str else None
        except ValueError:
            runtime = None
        
        # Calculate Input and Output sizes by summing child <uses> tags if available
        input_size = 0.0
        output_size = 0.0
        
        for use in job.findall(f"{ns}uses"):
            link = use.attrib.get("link", "").lower()
            size_str = use.attrib.get("size", "0")
            try:
                size = float(size_str)
                if link == "input":
                    input_size += size
                elif link == "output":
                    output_size += size
            except ValueError:
                pass
                
        tasks.append({
            "task_id": task_id,
            "task_name": task_name,
            "runtime": runtime,
            "input_size": input_size if input_size > 0 else None,
            "output_size": output_size if output_size > 0 else None
        })
        
    # Extract Dependencies
    for child in root.findall(f".//{ns}child"):
        child_id = child.attrib.get("ref")
        if not child_id:
            continue
        for parent in child.findall(f"{ns}parent"):
            parent_id = parent.attrib.get("ref")
            if parent_id:
                dependencies.append({
                    "parent_task_id": parent_id,
                    "child_task_id": child_id
                })
                
    return {
        "workflow_name": workflow_name,
        "tasks": tasks,
        "dependencies": dependencies
    }
