from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from backend.models import Workflow, WorkflowTask, WorkflowDependency, ClusteringResult
from backend.workflow.clustering import perform_kmeans_clustering
import logging

logger = logging.getLogger(__name__)

def store_parsed_workflow(db: Session, parsed_data: dict, filename: str, file_format: str, file_size: int) -> int:
    try:
        # 1. Create Workflow Record
        workflow = Workflow(
            filename=filename,
            workflow_name=parsed_data.get("workflow_name"),
            workflow_type="DAG",
            file_format=file_format,
            file_size=file_size,
            status="parsed"
        )
        db.add(workflow)
        db.flush() # Secure ID before children
        
        # 2. Add Task Records
        tasks_to_insert = []
        for t in parsed_data["tasks"]:
            tasks_to_insert.append(WorkflowTask(
                workflow_id=workflow.id,
                task_id=t["task_id"],
                task_name=t.get("task_name"),
                runtime=t.get("runtime"),
                input_size=t.get("input_size"),
                output_size=t.get("output_size")
            ))
        
        if tasks_to_insert:
            db.bulk_save_objects(tasks_to_insert)
            
        # 3. Add Dependency Records
        deps_to_insert = []
        for d in parsed_data["dependencies"]:
            deps_to_insert.append(WorkflowDependency(
                workflow_id=workflow.id,
                parent_task_id=d["parent_task_id"],
                child_task_id=d["child_task_id"]
            ))
            
        if deps_to_insert:
            db.bulk_save_objects(deps_to_insert)
            
        workflow.status = "stored"
        db.commit()
        return workflow.id
        
    except SQLAlchemyError as e:
        db.rollback()
        logger.error(f"Database transaction failed: {e}")
        raise Exception("Database transaction failed during workflow storage.")
    except Exception as e:
        db.rollback()
        logger.error(f"Unexpected error storing workflow: {e}")
        raise Exception(f"Failed to store workflow: {str(e)}")

def cluster_workflow_tasks(db: Session, workflow_id: int) -> dict:
    workflow = db.query(Workflow).filter(Workflow.id == workflow_id).first()
    if not workflow:
        raise ValueError("Workflow not found")
        
    tasks = db.query(WorkflowTask).filter(WorkflowTask.workflow_id == workflow_id).all()
    if not tasks:
        raise ValueError("Workflow has no tasks")
        
    tasks_data = [
        {
            "task_id": t.task_id,
            "runtime": t.runtime,
            "input_size": t.input_size,
            "output_size": t.output_size
        } for t in tasks
    ]
    
    # Run clustering logic
    cluster_info = perform_kmeans_clustering(tasks_data)
    
    # Persist the result
    try:
        result = ClusteringResult(
            workflow_id=workflow.id,
            algorithm="K-Means",
            cluster_count=cluster_info["selected_k"],
            silhouette_score=cluster_info["silhouette_score"],
            status="completed"
        )
        db.add(result)
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to persist clustering result: {e}")
        
    return cluster_info

