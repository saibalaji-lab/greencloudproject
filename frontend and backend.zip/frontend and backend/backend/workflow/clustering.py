import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import silhouette_score, davies_bouldin_score
import logging

logger = logging.getLogger(__name__)

def perform_kmeans_clustering(tasks_data: list[dict], min_k: int = 2, max_k: int = 8, random_state: int = 42) -> dict:
    df = pd.DataFrame(tasks_data)
    features = ['runtime', 'input_size', 'output_size']

    available_features = [f for f in features if f in df.columns]
    if not available_features:
        raise ValueError("No valid numeric features available for clustering.")

    X = df[available_features].copy()

    # Drop features that are entirely NULL across all tasks
    X.dropna(axis=1, how='all', inplace=True)
    active_features = list(X.columns)
    
    if not active_features:
        raise ValueError("All features are completely missing (NULL) for all tasks. Clustering impossible.")

    # Impute missing values with median for tasks that have some missing data
    try:
        imputer = SimpleImputer(strategy='median')
        X_imputed = imputer.fit_transform(X)
    except Exception as e:
        raise ValueError(f"Failed to impute missing values: {e}")

    # Scale the features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_imputed)

    n_samples = X_scaled.shape[0]
    if n_samples < 3:
        raise ValueError(f"Insufficient tasks for clustering. Need at least 3, got {n_samples}.")

    # Evaluate K candidates
    actual_max_k = min(max_k, n_samples - 1)
    if actual_max_k < min_k:
        raise ValueError("Not enough tasks to evaluate minimum K clusters.")

    best_k = min_k
    best_silhouette = -1.0
    best_labels = None
    best_db_score = float('inf')

    for k in range(min_k, actual_max_k + 1):
        kmeans = KMeans(n_clusters=k, random_state=random_state, n_init=10)
        labels = kmeans.fit_predict(X_scaled)
        
        sil_score = silhouette_score(X_scaled, labels)
        db_score = davies_bouldin_score(X_scaled, labels)

        # Selection preference: Higher Silhouette score
        if sil_score > best_silhouette:
            best_silhouette = sil_score
            best_db_score = db_score
            best_k = k
            best_labels = labels

    unique, counts = np.unique(best_labels, return_counts=True)
    distribution = []
    for label, count in zip(unique, counts):
        distribution.append({
            "cluster_label": int(label),
            "task_count": int(count),
            "percentage": round(float(count) / n_samples * 100, 2)
        })

    return {
        "algorithm": "K-Means",
        "selected_k": best_k,
        "silhouette_score": round(float(best_silhouette), 4),
        "davies_bouldin_score": round(float(best_db_score), 4),
        "task_count": n_samples,
        "cluster_distribution": distribution,
        "features_used": active_features,
        "labels": best_labels.tolist()
    }
