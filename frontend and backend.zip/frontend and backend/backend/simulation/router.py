from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from backend.database import engine, get_db
from backend.models import SimulationRun
from backend.simulation.schemas import SimulationRequest, SimulationResponse, SimulationStatusResponse
from backend.simulation.cloudsim_service import cloudsim_service
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

def get_db_optional():
    if engine is not None:
        try:
            db = next(get_db())
            yield db
        except Exception:
            yield None
        finally:
            if 'db' in locals() and db is not None:
                db.close()
    else:
        yield None

@router.get("/status", response_model=SimulationStatusResponse)
def get_simulation_status(db: Session = Depends(get_db_optional)):
    status_dict = cloudsim_service.get_status()
    return SimulationStatusResponse(
        cloudsim_configured=status_dict["cloudsim_configured"],
        java_available=status_dict["java_available"],
        cloudsim_project_available=status_dict["cloudsim_project_available"],
        simulation_service_available=status_dict["simulation_service_available"],
        database_available=(db is not None)
    )

@router.post("/run", response_model=SimulationResponse)
def run_simulation(request: SimulationRequest, db: Session = Depends(get_db_optional)):
    status_dict = cloudsim_service.get_status()
    if not status_dict["simulation_service_available"]:
        raise HTTPException(status_code=503, detail="Simulation service is not available (Java or JAR missing).")
        
    try:
        response = cloudsim_service.run_simulation(request)
    except Exception as e:
        logger.error(f"Simulation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
        
    db_persisted = False
    
    if request.persist_run:
        if db is not None:
            try:
                # count successful tasks
                success_count = sum(1 for c in response.cloudlets if c.status == "SUCCESS")
                
                sim_record = SimulationRun(
                    workflow_id=request.workflow_id,
                    simulation_engine="CloudSim Plus 7.3.0",
                    started_at=response.simulation_start,
                    completed_at=response.simulation_end,
                    status=response.status,
                    total_tasks=len(response.cloudlets),
                    completed_tasks=success_count,
                    total_energy=None, # Explicitly none per phase limits
                    total_carbon_emissions=None # Explicitly none
                )
                db.add(sim_record)
                db.commit()
                db_persisted = True
            except Exception as e:
                db.rollback()
                logger.error(f"Failed to persist simulation run to DB: {e}")
                
    response.database_persisted = db_persisted
    return response
