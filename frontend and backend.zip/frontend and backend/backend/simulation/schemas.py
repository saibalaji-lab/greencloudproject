from pydantic import BaseModel, Field
from typing import List, Optional, Dict
from datetime import datetime


class CloudSimHost(BaseModel):
    id: int
    pes: int
    mips: float
    ram: int
    bw: int
    storage: int


class CloudSimVM(BaseModel):
    id: int
    host_id: Optional[int]
    pes: int
    mips: float
    ram: int
    bw: int
    size: int


class CloudSimCloudlet(BaseModel):
    id: int
    vm_id: Optional[int]
    length: int
    pes: int
    file_size: int
    output_size: int


class MigrationRequest(BaseModel):
    vm_id: int
    target_host_id: int


class MigrationResult(BaseModel):
    vm_id: int
    source_host_id: int
    target_host_id: int
    success: bool


class SimulationRequest(BaseModel):
    workflow_id: int
    hosts: List[CloudSimHost] = Field(
        ...,
        description="Simulation configuration. These are not exact hardware traces.",
    )
    vms: List[CloudSimVM] = Field(
        ...,
        description="Simulation configuration.",
    )
    cloudlets: List[CloudSimCloudlet]
    migrations: Optional[List[MigrationRequest]] = None
    persist_run: bool = False


class CloudletResult(BaseModel):
    task_id: int
    vm_id: int
    host_id: int
    status: str
    start_time: float
    finish_time: float
    execution_time: float


class SimulationResponse(BaseModel):
    simulation_id: str
    workflow_id: int
    status: str
    simulation_start: Optional[datetime]
    simulation_end: Optional[datetime]
    total_simulation_time: Optional[float]
    cloudlets: List[CloudletResult]
    message: str
    migrations: Optional[List[MigrationResult]] = None
    database_persisted: bool


class SimulationStatusResponse(BaseModel):
    cloudsim_configured: bool
    java_available: bool
    cloudsim_project_available: bool
    simulation_service_available: bool
    database_available: bool