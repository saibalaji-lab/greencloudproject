import os
import subprocess
import json
import uuid
import logging
from datetime import datetime
from typing import Dict, Any
from backend.config import settings
from backend.simulation.schemas import SimulationRequest, SimulationResponse, CloudletResult, MigrationResult

logger = logging.getLogger(__name__)

class CloudSimService:
    def __init__(self):
        self.cloudsim_path = settings.CLOUDSIM_PATH or "/app/applet/app/cloudsim"
        self.java_cmd = "java"
        
    def _is_java_available(self) -> bool:
        try:
            subprocess.run([self.java_cmd, "-version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            return True
        except Exception:
            return False

    def _is_project_available(self) -> bool:
        if not self.cloudsim_path or not os.path.exists(self.cloudsim_path):
            return False
        # Check if the jar exists (we'll compile it)
        jar_path = os.path.join(self.cloudsim_path, "target", "greencloud-sim-1.0-jar-with-dependencies.jar")
        return os.path.exists(jar_path)

    def get_status(self) -> Dict[str, bool]:
        java_ok = self._is_java_available()
        proj_ok = self._is_project_available()
        return {
            "cloudsim_configured": bool(settings.CLOUDSIM_PATH),
            "java_available": java_ok,
            "cloudsim_project_available": proj_ok,
            "simulation_service_available": java_ok and proj_ok
        }

    def run_simulation(self, request: SimulationRequest) -> SimulationResponse:
        if not self._is_java_available():
            raise RuntimeError("Java is not available.")
        if not self._is_project_available():
            raise RuntimeError("CloudSim project JAR not found. Ensure the project is compiled.")

        sim_id = str(uuid.uuid4())
        
        # Prepare input JSON
        input_data = request.model_dump()
        input_data["simulation_id"] = sim_id
        
        input_file = os.path.join("/tmp", f"sim_request_{sim_id}.json")
        with open(input_file, "w") as f:
            json.dump(input_data, f)
            
        jar_path = os.path.join(self.cloudsim_path, "target", "greencloud-sim-1.0-jar-with-dependencies.jar")
        
        # Run Java process
        try:
            start_time = datetime.utcnow()
            
            process = subprocess.run(
                [self.java_cmd, "-jar", jar_path, input_file],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=60
            )
            
            end_time = datetime.utcnow()
            
            if process.returncode != 0:
                logger.error(f"Java simulation failed:\n{process.stderr}")
                raise RuntimeError(f"CloudSim execution failed. Check logs.")
                
            # Parse output JSON (the Java app should print ONLY JSON to stdout or write it to a file, let's have it print JSON to stdout)
            # Find the JSON block if there are logs
            output_str = process.stdout.strip()
            
            try:
                # Look for a marker or just parse the whole thing if it's pure JSON
                # Assuming the Java app prints clean JSON. 
                # If there are CloudSim logs, we should parse out the JSON string.
                # Let's say our Java app will output a line starting with "RESULT_JSON="
                result_json_str = None
                for line in output_str.splitlines():
                    if line.startswith("RESULT_JSON="):
                        result_json_str = line[len("RESULT_JSON="):]
                        break
                        
                if not result_json_str:
                    # try parsing the last line
                    result_json_str = output_str.splitlines()[-1]
                    
                result_data = json.loads(result_json_str)
                
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse CloudSim output: {output_str}")
                raise ValueError(f"Malformed JSON result from CloudSim: {e}")
                
            cloudlets = []
            for c in result_data.get("cloudlets", []):
                cloudlets.append(CloudletResult(
                    task_id=c["id"],
                    vm_id=c.get("vm_id", -1),
                    host_id=c.get("host_id", -1),
                    status=c.get("status", "FAILED"),
                    start_time=c.get("start_time", 0.0),
                    finish_time=c.get("finish_time", 0.0),
                    execution_time=c.get("execution_time", 0.0)
                ))
                
            return SimulationResponse(
                simulation_id=sim_id,
                workflow_id=request.workflow_id,
                status="SUCCESS",
                simulation_start=start_time,
                simulation_end=end_time,
                total_simulation_time=(end_time - start_time).total_seconds(),
                cloudlets=cloudlets,
                migrations=[MigrationResult(**m) for m in result_data.get("migrations", [])],
                message="Simulation completed successfully.",
                database_persisted=False
            )
            
        except subprocess.TimeoutExpired:
            logger.error("Simulation timed out.")
            raise RuntimeError("Simulation timed out after 60 seconds.")
        except Exception as e:
            logger.error(f"Simulation error: {e}")
            raise RuntimeError(str(e))
        finally:
            if os.path.exists(input_file):
                os.remove(input_file)

cloudsim_service = CloudSimService()
