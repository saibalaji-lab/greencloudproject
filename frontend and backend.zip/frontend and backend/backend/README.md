# GreenCloud Data Center Project

## Frontend
This is a React + Vite + TypeScript application representing the dashboard and module execution views.

## Backend (Phase 1)
The project includes a FastAPI backend foundation for managing workflow simulation and scheduling.

### Python Version
Requires Python 3.11+.

### Phase 1 Setup
Phase 1 establishes the FastAPI foundation. ML models, simulation engines (CloudSim/WorkflowSim), and MySQL databases are NOT implemented yet.

1. **Install Requirements:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Start the FastAPI Backend:**
   From the project root directory, run:
   ```bash
   python -m uvicorn backend.app:app --reload
   ```

3. **Endpoints:**
   - **Root:** `GET /` - Basic service identification
   - **Health:** `GET /api/health` - Component health status
   - **Swagger Docs:** `GET /docs` - Interactive API documentation
   - **ReDoc:** `GET /redoc` - Alternative API documentation

### Current Limitations (Phase 1)
- The backend is a foundation only.
- Database is not required (will report `not_configured`).
- ML Models, WorkflowSim, and CloudSim are placeholders.
- The React frontend does not yet make real API calls to this backend.