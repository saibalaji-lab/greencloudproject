# Shared dependencies for FastAPI services
