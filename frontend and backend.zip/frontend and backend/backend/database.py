from sqlalchemy import create_engine, text
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker
from backend.config import settings
import logging

logger = logging.getLogger(__name__)

# Do not crash if DATABASE_URL is not set
if settings.DATABASE_URL:
    try:
        engine = create_engine(settings.DATABASE_URL)
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    except Exception as e:
        logger.error(f"Failed to initialize database engine: {e}")
        engine = None
        SessionLocal = None
else:
    engine = None
    SessionLocal = None

Base = declarative_base()

def get_db():
    if not SessionLocal:
        raise Exception("Database not configured")
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    if engine:
        try:
            import backend.models
            Base.metadata.create_all(bind=engine)
        except Exception as e:
            logger.error(f"Failed to create tables: {e}")

def check_db_connection():
    if not settings.DATABASE_URL:
        return "not_configured"
    if not engine:
        return "unavailable"
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return "connected"
    except Exception:
        return "unavailable"
