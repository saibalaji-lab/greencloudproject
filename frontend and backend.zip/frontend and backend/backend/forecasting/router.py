from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from backend.database import engine, get_db
from backend.models import CarbonPrediction, RenewablePrediction
from backend.forecasting.schemas import (
    CarbonForecastRequest, CarbonForecastResponse, ModelStatusResponse,
    RenewableForecastRequest, RenewableForecastResponse
)
from backend.forecasting.carbon_service import carbon_service
from backend.forecasting.renewable_service import renewable_service
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

# Safely yield a DB connection without crashing if DB is unconfigured
def get_db_optional():
    if engine is not None:
        try:
            db = next(get_db())
            yield db
        except Exception:
            yield None
        finally:
            if 'db' in locals() and db is not None:
                db.close()
    else:
        yield None

@router.get("/carbon/status", response_model=ModelStatusResponse)
def get_carbon_model_status():
    return ModelStatusResponse(
        model_available=carbon_service.is_loaded,
        model_name=carbon_service.model_name,
        model_version=carbon_service.model_version,
        lookback=carbon_service.lookback,
        expected_feature_count=carbon_service.expected_feature_count,
        configured=carbon_service.is_configured,
        message="Model is loaded and ready." if carbon_service.is_loaded else "Model is not loaded."
    )

@router.post("/carbon", response_model=CarbonForecastResponse)
def predict_carbon(request: CarbonForecastRequest, db: Session = Depends(get_db_optional)):
    if not carbon_service.is_configured:
        raise HTTPException(status_code=503, detail="Carbon prediction service is not configured (CARBON_MODEL_PATH is missing).")
        
    if not carbon_service.is_loaded:
        raise HTTPException(status_code=503, detail="Carbon prediction model failed to load. Check server logs and artifact paths.")
        
    if len(request.observations) != carbon_service.lookback:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid lookback window. Expected exactly {carbon_service.lookback} observations, but received {len(request.observations)}."
        )
        
    obs_dicts = [
        {"timestamp": obs.timestamp, "g_co2_per_kwh": obs.g_co2_per_kwh} 
        for obs in request.observations
    ]
    
    db_persisted = False
    
    try:
        result = carbon_service.predict_next_step(obs_dicts)
        prediction_val = result["predicted_carbon_intensity"]
        
        # Database persistence
        if db is not None:
            try:
                db_record = CarbonPrediction(
                    timestamp=result.get("prediction_timestamp"),
                    actual_carbon_intensity=None, # Ground truth not known yet
                    predicted_carbon_intensity=prediction_val,
                    forecast_horizon=1,
                    model_name=carbon_service.model_name,
                    model_version=carbon_service.model_version
                )
                db.add(db_record)
                db.commit()
                db_persisted = True
            except Exception as e:
                db.rollback()
                logger.error(f"Failed to persist carbon prediction to DB: {e}")
        
        return CarbonForecastResponse(
            model_name=carbon_service.model_name,
            model_version=carbon_service.model_version,
            lookback=carbon_service.lookback,
            prediction_timestamp=result.get("prediction_timestamp"),
            predicted_carbon_intensity=prediction_val,
            unit="gCO2/kWh",
            status="success",
            database_persisted=db_persisted
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        logger.error(f"Unexpected error during carbon forecasting: {e}")
        raise HTTPException(status_code=500, detail="Internal server error during prediction.")

@router.get("/renewable/status", response_model=ModelStatusResponse)
def get_renewable_model_status():
    return ModelStatusResponse(
        model_available=renewable_service.is_loaded,
        model_name=renewable_service.model_name,
        model_version=renewable_service.model_version,
        lookback=renewable_service.lookback,
        expected_feature_count=renewable_service.expected_feature_count,
        configured=renewable_service.is_configured,
        message="Renewable Model is loaded and ready." if renewable_service.is_loaded else "Model is not loaded."
    )

@router.post("/renewable", response_model=RenewableForecastResponse)
def predict_renewable(request: RenewableForecastRequest, db: Session = Depends(get_db_optional)):
    if not renewable_service.is_configured:
        raise HTTPException(status_code=503, detail="Renewable prediction service is not configured (RENEWABLE_MODEL_PATH is missing).")
        
    if not renewable_service.is_loaded:
        raise HTTPException(status_code=503, detail="Renewable prediction model failed to load. Check server logs and artifact paths.")
        
    if len(request.observations) != renewable_service.lookback:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid lookback window. Expected exactly {renewable_service.lookback} observations, but received {len(request.observations)}."
        )
        
    obs_dicts = [
        {"date": obs.date, "total_renewable_generation_mu": obs.total_renewable_generation_mu} 
        for obs in request.observations
    ]
    
    db_persisted = False
    
    try:
        result = renewable_service.predict_next_step(obs_dicts)
        prediction_val = result["predicted_renewable_generation"]
        
        # Database persistence
        if db is not None:
            try:
                db_record = RenewablePrediction(
                    timestamp=result.get("prediction_date"),
                    actual_renewable_generation=None,
                    predicted_renewable_generation=prediction_val,
                    forecast_horizon=1,
                    model_name=renewable_service.model_name,
                    model_version=renewable_service.model_version
                )
                db.add(db_record)
                db.commit()
                db_persisted = True
            except Exception as e:
                db.rollback()
                logger.error(f"Failed to persist renewable prediction to DB: {e}")
                
        return RenewableForecastResponse(
            model_name=renewable_service.model_name,
            model_version=renewable_service.model_version,
            lookback=renewable_service.lookback,
            prediction_date=result.get("prediction_date"),
            predicted_renewable_generation=prediction_val,
            unit="MU",
            status="success",
            database_persisted=db_persisted
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        logger.error(f"Unexpected error during renewable forecasting: {e}")
        raise HTTPException(status_code=500, detail="Internal server error during prediction.")

