import os
import joblib
import numpy as np
import pandas as pd
from backend.config import settings
import logging

logger = logging.getLogger(__name__)

# Suppress TensorFlow logging to keep console clean
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf

class RenewablePredictionService:
    def __init__(self):
        self.model = None
        self.scaler = None
        self.is_configured = False
        self.is_loaded = False
        self.lookback = 30
        self.expected_feature_count = 6
        self.model_name = "Renewable LSTM V2"
        self.model_version = "v2.0.0"
        
        if settings.RENEWABLE_MODEL_PATH:
            self.is_configured = True
            self.load_artifacts()

    def load_artifacts(self):
        try:
            model_dir = os.path.dirname(settings.RENEWABLE_MODEL_PATH)
            scaler_path = os.path.join(model_dir, "renewable_scaler.pkl")
            
            if os.path.exists(settings.RENEWABLE_MODEL_PATH):
                self.model = tf.keras.models.load_model(settings.RENEWABLE_MODEL_PATH)
                if os.path.exists(scaler_path):
                    self.scaler = joblib.load(scaler_path)
                    self.is_loaded = True
                else:
                    logger.warning("Renewable model found but renewable_scaler.pkl is missing.")
            else:
                logger.warning(f"Renewable model path configured but file not found at {settings.RENEWABLE_MODEL_PATH}")
                
        except Exception as e:
            logger.error(f"Failed to load renewable prediction artifacts: {e}")

    def generate_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Derives temporal features to match exactly training preprocessing:
        day_sin, day_cos, week_sin, week_cos, is_weekend
        """
        df = df.copy()
        
        df['dayofyear'] = df['date'].dt.dayofyear
        df['dayofweek'] = df['date'].dt.dayofweek
        
        # Temporal Cyclical Encoding for annual seasonality (365.25 for leap year generalized)
        df['day_sin'] = np.sin(2 * np.pi * df['dayofyear'] / 365.25)
        df['day_cos'] = np.cos(2 * np.pi * df['dayofyear'] / 365.25)
        
        # Week cyclical encoding (assuming 7 days)
        df['week_sin'] = np.sin(2 * np.pi * df['dayofweek'] / 7.0)
        df['week_cos'] = np.cos(2 * np.pi * df['dayofweek'] / 7.0)
        
        # Weekend boolean
        df['is_weekend'] = (df['dayofweek'] >= 5).astype(float)
        
        # IMPORTANT: Do not include wind/solar/other leakage metrics per Phase 6 requirements
        features = ['total_renewable_generation_mu', 'day_sin', 'day_cos', 'week_sin', 'week_cos', 'is_weekend']
        return df[features]

    def predict_next_step(self, observations: list[dict]) -> dict:
        if not self.is_loaded or self.model is None or self.scaler is None:
            raise RuntimeError("Renewable Model or preprocessing artifacts are not loaded.")
            
        if len(observations) != self.lookback:
            raise ValueError(f"Expected exactly {self.lookback} daily observations. Received {len(observations)}.")
            
        # Convert to DataFrame to process temporal features
        df = pd.DataFrame(observations)
        df['date'] = pd.to_datetime(df['date'])
        
        # Ensure sequential ordering
        df = df.sort_values(by='date').reset_index(drop=True)
        
        # Target prediction timestamp
        last_date = df['date'].iloc[-1]
        
        # Generate feature matrix
        feature_df = self.generate_features(df)
        
        # Scale
        try:
            scaled_features = self.scaler.transform(feature_df)
        except Exception as e:
            raise ValueError(f"Failed to scale input features. Scaler mismatch? Error: {e}")
            
        # Reshape for LSTM: [samples, time steps, features]
        sequence = scaled_features.reshape((1, self.lookback, self.expected_feature_count))
        
        # Predict
        try:
            scaled_prediction = self.model.predict(sequence, verbose=0)
            
            # Inverse transform requires building a dummy array matching the scaler's expected feature count
            dummy_array = np.zeros((1, self.expected_feature_count))
            # Place target in the first column index which matches preprocessing schema
            dummy_array[0, 0] = scaled_prediction[0, 0]
            
            inverse_prediction = self.scaler.inverse_transform(dummy_array)
            final_pred_value = float(inverse_prediction[0, 0])
            
        except Exception as e:
            logger.error(f"Prediction failed: {e}")
            raise RuntimeError("Model failed to execute prediction.")
            
        return {
            "predicted_renewable_generation": final_pred_value,
            "prediction_date": last_date, 
        }

# Singleton service instance
renewable_service = RenewablePredictionService()
