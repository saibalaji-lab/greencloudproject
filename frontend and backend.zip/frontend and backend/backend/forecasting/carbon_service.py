import os
import joblib
import numpy as np
import pandas as pd
from backend.config import settings
import logging

logger = logging.getLogger(__name__)

# Suppress TensorFlow logging to keep console clean
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf

class CarbonPredictionService:
    def __init__(self):
        self.model = None
        self.scaler = None
        self.is_configured = False
        self.is_loaded = False
        self.lookback = 12
        self.expected_feature_count = 6
        self.model_name = "Carbon Residual LSTM V2"
        self.model_version = "v2.0.0"
        
        if settings.CARBON_MODEL_PATH:
            self.is_configured = True
            self.load_artifacts()

    def load_artifacts(self):
        try:
            # Assumes scaler is kept next to the model path e.g. path/scaler.pkl
            model_dir = os.path.dirname(settings.CARBON_MODEL_PATH)
            scaler_path = os.path.join(model_dir, "carbon_scaler.pkl")
            
            if os.path.exists(settings.CARBON_MODEL_PATH):
                self.model = tf.keras.models.load_model(settings.CARBON_MODEL_PATH)
                if os.path.exists(scaler_path):
                    self.scaler = joblib.load(scaler_path)
                    self.is_loaded = True
                else:
                    logger.warning("Carbon model found but scaler.pkl is missing.")
            else:
                logger.warning(f"Carbon model path configured but file not found at {settings.CARBON_MODEL_PATH}")
                
        except Exception as e:
            logger.error(f"Failed to load carbon prediction artifacts: {e}")

    def generate_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Derives temporal features to match the exact training preprocessing:
        hour_sin, hour_cos, week_sin, week_cos, is_weekend
        """
        df = df.copy()
        
        df['hour'] = df['timestamp'].dt.hour
        df['dayofweek'] = df['timestamp'].dt.dayofweek
        
        # Temporal Cyclical Encoding
        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24.0)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24.0)
        
        # Week cyclical encoding (assuming 7 days)
        df['week_sin'] = np.sin(2 * np.pi * df['dayofweek'] / 7.0)
        df['week_cos'] = np.cos(2 * np.pi * df['dayofweek'] / 7.0)
        
        # Weekend boolean
        df['is_weekend'] = (df['dayofweek'] >= 5).astype(float)
        
        features = ['g_co2_per_kwh', 'hour_sin', 'hour_cos', 'week_sin', 'week_cos', 'is_weekend']
        return df[features]

    def predict_next_step(self, observations: list[dict]) -> dict:
        if not self.is_loaded or self.model is None or self.scaler is None:
            raise RuntimeError("Model or preprocessing artifacts are not loaded.")
            
        if len(observations) != self.lookback:
            raise ValueError(f"Expected exactly {self.lookback} observations. Received {len(observations)}.")
            
        # Convert to DataFrame to process temporal features
        df = pd.DataFrame(observations)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Ensure sequential ordering
        df = df.sort_values(by='timestamp').reset_index(drop=True)
        
        # Target prediction timestamp (usually +1 period from last observation)
        last_timestamp = df['timestamp'].iloc[-1]
        
        # Generate feature matrix
        feature_df = self.generate_features(df)
        
        # Scale
        try:
            scaled_features = self.scaler.transform(feature_df)
        except Exception as e:
            raise ValueError(f"Failed to scale input features. Scaler mismatch? Error: {e}")
            
        # Reshape for LSTM: [samples, time steps, features]
        sequence = scaled_features.reshape((1, self.lookback, self.expected_feature_count))
        
        # Predict
        try:
            scaled_prediction = self.model.predict(sequence, verbose=0)
            
            # Inverse transform requires building a dummy array matching the scaler's expected feature count
            # since the scaler scaled all 6 features, but we only predicted the 1 target.
            # Assuming g_co2_per_kwh is the FIRST column (index 0) in the scaled layout:
            dummy_array = np.zeros((1, self.expected_feature_count))
            dummy_array[0, 0] = scaled_prediction[0, 0]
            
            inverse_prediction = self.scaler.inverse_transform(dummy_array)
            final_pred_value = float(inverse_prediction[0, 0])
            
        except Exception as e:
            logger.error(f"Prediction failed: {e}")
            raise RuntimeError("Model failed to execute prediction.")
            
        return {
            "predicted_carbon_intensity": final_pred_value,
            "prediction_timestamp": last_timestamp, # Technically +1 timestep, but left uncalculated cleanly for neutral API output
        }

# Singleton service instance
carbon_service = CarbonPredictionService()
