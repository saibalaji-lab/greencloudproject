from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class HistoricalObservation(BaseModel):
    timestamp: datetime
    g_co2_per_kwh: float

class CarbonForecastRequest(BaseModel):
    observations: List[HistoricalObservation] = Field(..., description="Must provide exactly the lookback window length of observations, sequentially ordered.", min_items=1)

class CarbonForecastResponse(BaseModel):
    model_name: str
    model_version: str
    lookback: int
    prediction_timestamp: Optional[datetime]
    predicted_carbon_intensity: float
    unit: str
    status: str
    database_persisted: bool

class RenewableObservation(BaseModel):
    date: datetime
    total_renewable_generation_mu: float

class RenewableForecastRequest(BaseModel):
    observations: List[RenewableObservation] = Field(..., description="Must provide exactly the 30-day lookback window length of observations, sequentially ordered.", min_items=30)

class RenewableForecastResponse(BaseModel):
    model_name: str
    model_version: str
    lookback: int
    prediction_date: Optional[datetime]
    predicted_renewable_generation: float
    unit: str
    status: str
    database_persisted: bool

class ModelStatusResponse(BaseModel):
    model_available: bool
    model_name: str
    model_version: str
    lookback: int
    expected_feature_count: int
    configured: bool
    message: str
