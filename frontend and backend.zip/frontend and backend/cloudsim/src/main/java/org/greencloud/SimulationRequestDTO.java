package org.greencloud;

import java.util.List;

public class SimulationRequestDTO {
    public int workflow_id;
    public String simulation_id;
    public List<CloudSimHostDTO> hosts;
    public List<CloudSimVmDTO> vms;
    public List<CloudSimCloudletDTO> cloudlets;
    public List<MigrationRequestDTO> migrations;
    public boolean persist_run;
}
