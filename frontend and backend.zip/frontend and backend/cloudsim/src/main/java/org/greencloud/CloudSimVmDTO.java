package org.greencloud;

public class CloudSimVmDTO {
    public int id;
    public Integer host_id;
    public int pes;
    public double mips;
    public int ram;
    public long bw;
    public long size;
}
