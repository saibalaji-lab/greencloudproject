package org.greencloud;

import java.util.List;

public class CloudSimHostDTO {
    public int id;
    public int pes;
    public double mips;
    public int ram;
    public long bw;
    public long storage;
}
