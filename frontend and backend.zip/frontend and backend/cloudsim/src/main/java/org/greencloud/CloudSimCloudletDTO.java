package org.greencloud;

public class CloudSimCloudletDTO {
    public int id;
    public Integer vm_id;
    public long length;
    public int pes;
    public long file_size;
    public long output_size;
}
