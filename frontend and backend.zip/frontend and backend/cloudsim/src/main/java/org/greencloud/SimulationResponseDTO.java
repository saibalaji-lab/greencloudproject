package org.greencloud;

import java.util.List;
import java.util.ArrayList;

public class SimulationResponseDTO {
    public String simulation_id;
    public int workflow_id;
    public List<CloudletResultDTO> cloudlets = new ArrayList<>();
    public List<MigrationResultDTO> migrations = new ArrayList<>();
}
