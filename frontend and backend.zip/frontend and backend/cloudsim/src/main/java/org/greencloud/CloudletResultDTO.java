package org.greencloud;

public class CloudletResultDTO {
    public int id;
    public int vm_id;
    public int host_id;
    public String status;
    public double start_time;
    public double finish_time;
    public double execution_time;
}
