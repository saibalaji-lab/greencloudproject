package org.greencloud;

import com.google.gson.Gson;
import org.cloudbus.cloudsim.allocationpolicies.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.brokers.DatacenterBroker;
import org.cloudbus.cloudsim.brokers.DatacenterBrokerSimple;
import org.cloudbus.cloudsim.cloudlets.Cloudlet;
import org.cloudbus.cloudsim.cloudlets.CloudletSimple;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.datacenters.Datacenter;
import org.cloudbus.cloudsim.datacenters.DatacenterSimple;
import org.cloudbus.cloudsim.hosts.Host;
import org.cloudbus.cloudsim.hosts.HostSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.resources.Pe;
import org.cloudbus.cloudsim.resources.PeSimple;
import org.cloudbus.cloudsim.schedulers.cloudlet.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.schedulers.vm.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.utilizationmodels.UtilizationModelFull;
import org.cloudbus.cloudsim.vms.Vm;
import org.cloudbus.cloudsim.vms.VmSimple;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class SimulationRunner {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("Please provide the path to the JSON request file.");
            System.exit(1);
        }
        String jsonPath = args[0];
        try {
            String jsonContent = new String(Files.readAllBytes(Paths.get(jsonPath)));
            Gson gson = new Gson();
            SimulationRequestDTO request = gson.fromJson(jsonContent, SimulationRequestDTO.class);
            CloudSim simulation = new CloudSim();

            List<Host> hostList = new ArrayList<>();
            for (CloudSimHostDTO hDto : request.hosts) {
                List<Pe> peList = new ArrayList<>();
                for (int i = 0; i < hDto.pes; i++) {
                    peList.add(new PeSimple(hDto.mips, new PeProvisionerSimple()));
                }
                Host host = new HostSimple(hDto.ram, hDto.bw, hDto.storage, peList);
                host.setVmScheduler(new VmSchedulerTimeShared());
                host.setId(hDto.id);
                hostList.add(host);
            }

            Datacenter datacenter = new DatacenterSimple(simulation, hostList, new VmAllocationPolicySimple());
            DatacenterBroker broker = new DatacenterBrokerSimple(simulation);

            List<Vm> vmList = new ArrayList<>();
            for (CloudSimVmDTO vDto : request.vms) {
                Vm vm = new VmSimple(vDto.id, vDto.mips, vDto.pes)
                        .setRam(vDto.ram)
                        .setBw(vDto.bw)
                        .setSize(vDto.size)
                        .setCloudletScheduler(new CloudletSchedulerTimeShared());
                
                // Bind to host explicitly if host_id is given (so initial mapping matches request)
                if (vDto.host_id != null) {
                    Host targetHost = hostList.stream().filter(h -> h.getId() == vDto.host_id).findFirst().orElse(null);
                    if (targetHost != null) {
                        vm.setHost(targetHost);
                    }
                }
                vmList.add(vm);
            }
            broker.submitVmList(vmList);

            List<Cloudlet> cloudletList = new ArrayList<>();
            for (CloudSimCloudletDTO cDto : request.cloudlets) {
                UtilizationModelFull utilizationModel = new UtilizationModelFull();
                Cloudlet cloudlet = new CloudletSimple(cDto.id, cDto.length, cDto.pes)
                        .setFileSize(cDto.file_size)
                        .setOutputSize(cDto.output_size)
                        .setUtilizationModel(utilizationModel);
                if (cDto.vm_id != null) {
                    broker.bindCloudletToVm(cloudlet, broker.getVmWaitingList().stream()
                        .filter(v -> v.getId() == cDto.vm_id)
                        .findFirst().orElse(vmList.get(0)));
                }
                cloudletList.add(cloudlet);
            }
            broker.submitCloudletList(cloudletList);

            if (request.migrations != null && !request.migrations.isEmpty()) {
                simulation.addOnClockTickListener(e -> {
                    if (e.getTime() == 1.0) {
                        for (MigrationRequestDTO m : request.migrations) {
                            Vm vm = vmList.stream().filter(v -> v.getId() == m.vm_id).findFirst().orElse(null);
                            Host target = hostList.stream().filter(h -> h.getId() == m.target_host_id).findFirst().orElse(null);
                            if (vm != null && target != null) {
                                datacenter.requestVmMigration(vm, target);
                            }
                        }
                    }
                });
            }

            simulation.start();

            SimulationResponseDTO response = new SimulationResponseDTO();
            response.simulation_id = request.simulation_id;
            response.workflow_id = request.workflow_id;

            List<Cloudlet> finishedCloudlets = broker.getCloudletFinishedList();
            for (Cloudlet cl : finishedCloudlets) {
                CloudletResultDTO res = new CloudletResultDTO();
                res.id = (int) cl.getId();
                if (cl.getVm() != null) {
                    res.vm_id = (int) cl.getVm().getId();
                    if (cl.getVm().getHost() != null) {
                        res.host_id = (int) cl.getVm().getHost().getId();
                    }
                }
                res.status = cl.getStatus().name();
                res.start_time = cl.getExecStartTime();
                res.finish_time = cl.getFinishTime();
                res.execution_time = cl.getActualCpuTime();
                response.cloudlets.add(res);
            }

            if (request.migrations != null) {
                for (MigrationRequestDTO m : request.migrations) {
                    Vm vm = vmList.stream().filter(v -> v.getId() == m.vm_id).findFirst().orElse(null);
                    if (vm != null) {
                        MigrationResultDTO res = new MigrationResultDTO();
                        res.vm_id = m.vm_id;
                        res.target_host_id = m.target_host_id;
                        res.source_host_id = -1;
                        for (CloudSimVmDTO vDto : request.vms) {
                            if (vDto.id == m.vm_id && vDto.host_id != null) {
                                res.source_host_id = vDto.host_id;
                            }
                        }
                        res.success = (vm.getHost() != null && vm.getHost().getId() == m.target_host_id);
                        response.migrations.add(res);
                    }
                }
            }

            String resultJson = gson.toJson(response);
            System.out.println("RESULT_JSON=" + resultJson);

        } catch (Exception e) {
            System.err.println("Failed to execute simulation: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
