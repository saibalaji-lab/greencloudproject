package org.greencloud;

public class MigrationResultDTO {
    public int vm_id;
    public int source_host_id;
    public int target_host_id;
    public boolean success;
}
