package org.greencloud;

public class MigrationRequestDTO {
    public int vm_id;
    public int target_host_id;
}
